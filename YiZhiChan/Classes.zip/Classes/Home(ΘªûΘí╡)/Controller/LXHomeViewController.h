//
//  LXHomeViewController.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/26.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXBaseViewController.h"

@interface LXHomeViewController : LXBaseViewController

@end
