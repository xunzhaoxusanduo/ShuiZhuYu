//
//  LXHomeViewController.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/26.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXHomeViewController.h"
#import "LXSuspendCollectionView.h"
#import "LXRecommendMovieView.h"
#import "LXRecommendMovie.h"
#import "LXRecommendMovieCell.h"
#import "LXNewMovie.h"
#import "LXNewMovieCell.h"
#import "LXAdvert.h"
#import "LXAdvertCell.h"
#import "LXShow.h"
#import "LXShowCell.h"
#import "LXHomePlate.h"
#import "LXCellHeader.h"
#import "LXCellHeaderView.h"
#import "LXMoviePoster.h"
#import "LXWebViewController.h"
#import "LXCommentCell.h"
#import "LXComment.h"

#import "UINavigationBar+Extend.h"
#import "Macros.h"

#import "AFNetworking.h"
#import "MJExtension.h"
#import "SDCycleScrollView.h"
#import "Masonry.h"
#import "UITableView+FDTemplateLayoutCell.h"
#import "RxWebViewController.h"
#import "YMCitySelect.h"

#import "LXAssistiveView.h"
#import "LXAssistiveViewBorder.h"

#define Bundle [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:@"shuizhuyu" ofType:@"bundle"]];

static NSString *recommendMovieCellID = @"recommendMovieCellID";
static NSString *latestMovieCellID = @"latestMovieCellID";
static NSString *showCellID = @"showCellID";
static NSString *commentCellID = @"commentCellID";
static NSString *advertCellID = @"advertCellID";

@interface LXHomeViewController () <SDCycleScrollViewDelegate, UIScrollViewDelegate, UITableViewDelegate,
                                    UITableViewDataSource, LXSuspendCollectionViewDelegate, LXCellHeaderViewDelegate,
                                    LXRecommendMovieCellDelegate, LXAssistiveViewDelegate, YMCitySelectDelegate>

@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)SDCycleScrollView *bgScrollView;
@property (nonatomic, strong)LXSuspendCollectionView *suspendCollectionView;
@property (nonatomic, strong)LXAssistiveView *assistiveView;
@property (nonatomic, strong)UIVisualEffectView *visualEffectView;
@property (nonatomic, strong)UIButton *locationBtn;

// 板块模型数组
@property (nonatomic, strong)NSMutableArray *homePlateArray;
// 电影海报数组
@property (nonatomic, strong)NSMutableArray *moviePosterArray;
// 推荐电影场次数组
@property (nonatomic, strong)NSMutableArray *recommendMovieArray;
// 新影讯数组
@property (nonatomic, strong)NSMutableArray *latestMovieArray;
// 玩吧数组
@property (nonatomic, strong)NSMutableArray *playArray;
// 神评论数组
@property (nonatomic, strong)NSMutableArray *commentArray;
// 广告数组
@property (nonatomic, strong)NSMutableArray *advertArray;

@end

@implementation LXHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupNavBar];
    [self setupbgScrollView];
    [self setupBlackBackground];
    
    UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    UIVisualEffectView *visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    visualEffectView.frame = self.bgScrollView.frame;
    visualEffectView.alpha = 0.0;
    [self.bgScrollView addSubview:visualEffectView];
    self.visualEffectView = visualEffectView;
    
    [self setupTableView];
    [self setupAssistiveView];
    [self setupGesture];
    
    [self loadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.tableView.delegate = self;
    [self scrollViewDidScroll:self.tableView];
    
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
}

#pragma mark - 懒加载
- (NSMutableArray *)homePlateArray {
    if (_homePlateArray == nil) {
        _homePlateArray = [NSMutableArray array];
    }
    
    return _homePlateArray;
}

- (NSMutableArray *)moviePosterArray {
    if (_moviePosterArray == nil) {
        _moviePosterArray = [NSMutableArray array];
    }
    
    return _moviePosterArray;
}

- (NSMutableArray *)recommendMovieArray {
    if (_recommendMovieArray == nil) {
        _recommendMovieArray = [NSMutableArray array];
    }
    
    return _recommendMovieArray;
}

- (NSMutableArray *)latestMovieArray {
    if (_latestMovieArray == nil) {
        _latestMovieArray = [NSMutableArray array];
    }
    
    return _latestMovieArray;
}

- (NSMutableArray *)playArray {
    if (_playArray == nil) {
        _playArray = [NSMutableArray array];
    }
    
    return _playArray;
}

- (NSMutableArray *)commentArray {
    if (_commentArray == nil) {
        _commentArray = [NSMutableArray array];
    }
    
    return _commentArray;
}

- (NSMutableArray *)advertArray {
    if (_advertArray == nil) {
        _advertArray = [NSMutableArray array];
    }
    
    return _advertArray;
}

#pragma mark - 私有方法
/**
 *  设置导航栏的内容
 */
- (void)setupNavBar {
    self.navigationItem.title = @"";
    
    UIButton *locationBtn = [UIButton buttonWithType:UIButtonTypeSystem];
//    locationBtn.backgroundColor = [UIColor grayColor];
    locationBtn.frame = CGRectMake(0, 0, 90, 30);
    [locationBtn setImage:[UIImage imageNamed:@"navBar_location"] forState:UIControlStateNormal];
    locationBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    locationBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [locationBtn setTitle:@"上海市" forState:UIControlStateNormal];
    locationBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 2, 0, 0);
    [locationBtn addTarget:self action:@selector(citySelect) forControlEvents:UIControlEventTouchUpInside];
    self.locationBtn = locationBtn;
    UIBarButtonItem *locationBtnItem = [[UIBarButtonItem alloc] initWithCustomView:locationBtn];

    UIBarButtonItem *navigationLeftSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    navigationLeftSpacer.width = -5;
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:navigationLeftSpacer, locationBtnItem,nil];
    
    
    UIButton *searchBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    searchBtn.frame = CGRectMake(0, 0, 25, 25);
    [searchBtn setImage:[UIImage imageNamed:@"navBar_search"] forState:UIControlStateNormal];
    searchBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:searchBtn];
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
}

- (void)citySelect {
    [self presentViewController:[[YMCitySelect alloc] initWithDelegate:self] animated:YES completion:nil];
}

/**
 *  设置背景轮播图片
 */
- (void)setupbgScrollView{
    NSArray *imagesURLStrings = @[
                                  @"http://c.hiphotos.baidu.com/image/w%3D400/sign=c2318ff84334970a4773112fa5c8d1c0/b7fd5266d0160924c1fae5ccd60735fae7cd340d.jpg",
                                  @"https://ss2.baidu.com/-vo3dSag_xI4khGko9WTAnF6hhy/super/whfpf%3D425%2C260%2C50/sign=a4b3d7085dee3d6d2293d48b252b5910/0e2442a7d933c89524cd5cd4d51373f0830200ea.jpg",
                                  @"https://ss0.baidu.com/-Po3dSag_xI4khGko9WTAnF6hhy/super/whfpf%3D425%2C260%2C50/sign=a41eb338dd33c895a62bcb3bb72e47c2/5fdf8db1cb134954a2192ccb524e9258d1094a1e.jpg"
                                  ];
    SDCycleScrollView *bgScrollView = [SDCycleScrollView cycleScrollViewWithFrame:self.view.frame delegate:self placeholderImage:[UIImage imageNamed:@"placeholder"]];
    bgScrollView.showPageControl = NO;
    bgScrollView.autoScroll = NO;
    bgScrollView.infiniteLoop = NO;
    bgScrollView.bannerImageViewContentMode = UIViewContentModeScaleAspectFill;
    self.bgScrollView = bgScrollView;
    [self.view addSubview:bgScrollView];
//    bgScrollView.imageURLStringsGroup = imagesURLStrings;
}

/**
 *  设置黑色渐变背景
 */
- (void)setupBlackBackground {
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Bottom-bg"]];
    CGFloat x = 0;
    CGFloat height = self.view.frame.size.height * 0.3;
    CGFloat y = self.view.frame.size.height - CGRectGetHeight(self.tabBarController.tabBar.frame) - height;
    CGFloat width = self.view.frame.size.width;
    imageView.frame = CGRectMake(x, y, width, height);
    [self.view addSubview:imageView];
}

/**
 *  添加移动按钮
 */
- (void)setupAssistiveView {
    LXAssistiveViewBorder *left = [[LXAssistiveViewBorder alloc] initWithType:LXAssistiveViewBorderTypeLeft];
    LXAssistiveViewBorder *right = [[LXAssistiveViewBorder alloc] initWithType:LXAssistiveViewBorderTypeRight];
    LXAssistiveViewBorder *bottom = [[LXAssistiveViewBorder alloc] initWithType:LXAssistiveViewBorderTypeBottom];
    
    LXAssistiveView *assistiveView = [[LXAssistiveView alloc] initWithFrame:CGRectMake(50, 400, 100, 100)];
    assistiveView.supportBorders = [NSMutableArray arrayWithObjects:left, right, bottom, nil];
    assistiveView.borderEdge = UIEdgeInsetsMake(64, 0, 49, 0);
    assistiveView.delegate = self;
    [self.view addSubview:assistiveView];
    LXAssistiveViewBorder *startLeft = [[LXAssistiveViewBorder alloc] initWithType:LXAssistiveViewBorderTypeLeft];
    [assistiveView startAttachmentAtBorder:startLeft];
}

/**
 *  添加tableView
 */
- (void)setupTableView {
    // headerView与tableView第一个cell之间的间距
    CGFloat headerBottomInset = 63;
    CGRect frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height + headerBottomInset);
    CGRect moveFrame = CGRectMake(0, 200, CGRectGetWidth(frame), CGRectGetHeight(frame) - 200 - TabBarHeight);
    LXSuspendCollectionView *collectionView = [[LXSuspendCollectionView alloc] initWithVisibleFrame:frame
                                                withMoveFrame:moveFrame
                                                itemSize:CGSizeMake(50, 80)
                                                sectionInset:UIEdgeInsetsMake(0, 10, TabBarHeight + 20 + headerBottomInset, 10)
                                                minimumLineSpacing:5
                                                minimumInteritemSpacing:10];
    collectionView.delegate = self;
    self.suspendCollectionView = collectionView;
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStyleGrouped];
    tableView.backgroundColor = [UIColor clearColor];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.tableHeaderView = self.suspendCollectionView;
    tableView.contentInset = UIEdgeInsetsMake(0, 0, 49, 0);
    
    [tableView registerClass:[LXRecommendMovieCell class] forCellReuseIdentifier:recommendMovieCellID];
    [tableView registerClass:[LXNewMovieCell class] forCellReuseIdentifier:latestMovieCellID];
    [tableView registerClass:[LXShowCell class] forCellReuseIdentifier:showCellID];
    [tableView registerClass:[LXCommentCell class] forCellReuseIdentifier:commentCellID];
    [tableView registerClass:[LXAdvertCell class] forCellReuseIdentifier:advertCellID];
    
    [self.view addSubview:tableView];
    self.tableView = tableView;
}

/**
 *  添加手势识别器
 */
- (void)setupGesture {
    UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    [self.view addGestureRecognizer:panGestureRecognizer];
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
    [self.suspendCollectionView addGestureRecognizer:tapGestureRecognizer];
    
    UISwipeGestureRecognizer *leftSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipGesture:)];
    leftSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:leftSwipeGestureRecognizer];
}

/**
 *  拖动手势识别
 *
 *  @param sender 拖动手势识别器对象
 *  因为滚动背景视图位于视图层次最下面，不能相应手势，故加一个拖动手势识别器
 */
- (void)handlePanGesture:(UIPanGestureRecognizer *)sender {
    static CGPoint startPoint;
    static CGPoint startContentOffset;
    // YES:右滑 NO：左滑
    static BOOL direction;
    
    CGPoint point = [sender locationInView:self.view];
    switch (sender.state) {
        case UIGestureRecognizerStateBegan:{
            startPoint = point;
            startContentOffset = self.bgScrollView.mainView.contentOffset;
            break;
        }
        case UIGestureRecognizerStateChanged:{
            CGFloat x = startContentOffset.x + startPoint.x - point.x;
            x = MIN(MAX(0, x), self.bgScrollView.mainView.contentSize.width - self.bgScrollView.frame.size.width);
            [self.bgScrollView.mainView setContentOffset:CGPointMake(x, 0)];
            
            // 左滑
            if ((point.x - startPoint.x) < 0) {
                direction = NO;
            }else {// 右滑
                direction = YES;
            }
            break;
        }
        case UIGestureRecognizerStateEnded:{
            if (direction) {
                [self.bgScrollView upImage];
            }else {
                [self.bgScrollView downImage];
            }
            break;
        }
        case UIGestureRecognizerStateCancelled:{
            if (direction) {
                [self.bgScrollView upImage];
            }else {
                [self.bgScrollView downImage];
            }
            break;
        }
        default:
            break;
    }
}

/**
 *  点击手势处理
 *  用于处理点击海报
 */
- (void)handleTapGesture:(UITapGestureRecognizer *)sender {
    NSLog(@"handleTapGesture");
    int index = [self.bgScrollView currentIndex];
    LXMoviePoster *moviePoster = self.moviePosterArray[index];
    NSString *url = moviePoster.url;
    NSLog(@"url:%@", url);
}

- (void)handleSwipGesture:(UISwipeGestureRecognizer *)sender {
    NSLog(@"direcation %lu", (unsigned long)sender.direction);
    
    static CGPoint startPoint;
    static CGPoint startContentOffset;
    
    CGPoint point = [sender locationInView:self.view];
    switch (sender.state) {
        case UIGestureRecognizerStateBegan:{
            startPoint = point;
            startContentOffset = self.bgScrollView.mainView.contentOffset;
            break;
        }
        case UIGestureRecognizerStateChanged:{
            CGFloat x = startContentOffset.x + startPoint.x - point.x;
            x = MIN(MAX(0, x), self.bgScrollView.mainView.contentSize.width - self.bgScrollView.frame.size.width);
            [self.bgScrollView.mainView setContentOffset:CGPointMake(x, 0)];
            break;
        }
        case UIGestureRecognizerStateEnded:{
            [self.bgScrollView automaticScroll1];
            break;
        }
        case UIGestureRecognizerStateCancelled:{
            [self.bgScrollView automaticScroll1];
            break;
        }
        default:
            break;
    }
}

/**
 *  加载数据
 */
- (void)loadData {
    [self loadMoviePoster];
    [self loadHomePlate];
}

/**
 *  加载海报数据
 */
- (void)loadMoviePoster {
//    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
//    
//    [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:nil
//     success:^(AFHTTPRequestOperation *operation, id responseObject) {
//         if ([responseObject[@"state"] intValue] == 1) {
//             self.moviePosterArray = (NSMutableArray *)[LXMoviePoster objectArrayWithKeyValuesArray:responseObject[@"data"]];
//         }
//         
//         NSMutableArray *imagesURLStringsArray = [NSMutableArray array];
//         for (LXMoviePoster *moviePoster in self.moviePosterArray) {
//             [imagesURLStringsArray addObject:moviePoster.imageUrl];
//         }
//         
//         self.bgScrollView.imageURLStringsGroup = imagesURLStringsArray;
//     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//         
//     }];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *dataFilePath = [[NSBundle mainBundle] pathForResource:@"bgView" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:dataFilePath];
        NSDictionary *responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if ([responseObject[@"state"] intValue] == 1) {
            self.moviePosterArray = (NSMutableArray *)[LXMoviePoster objectArrayWithKeyValuesArray:responseObject[@"data"]];
        }
        
         NSMutableArray *imagesURLStringsArray = [NSMutableArray array];
         for (LXMoviePoster *moviePoster in self.moviePosterArray) {
             [imagesURLStringsArray addObject:moviePoster.imageUrl];
         }
        dispatch_async(dispatch_get_main_queue(), ^{
            self.bgScrollView.localizationImageNamesGroup = imagesURLStringsArray;
        });
    });
}

/**
 *  加载板块数据
 */
- (void)loadHomePlate {
//    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
//    
//    [mgr GET:@"http://devftp.lansum.cn/fishapi/api/Home/IndexMovie" parameters:nil
//     success:^(AFHTTPRequestOperation *operation, id responseObject) {
//         if ([responseObject[@"state"] intValue] == 1) {
//             self.homePlateArray = (NSMutableArray *)[LXHomePlate objectArrayWithKeyValuesArray:responseObject[@"data"]];
//         }
//         
//         dispatch_async(dispatch_get_main_queue(), ^{
//              [self.tableView reloadData];
//         });
//     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//         
//     }];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *dataFilePath = [[NSBundle mainBundle] pathForResource:@"homePlate" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:dataFilePath];
        NSError *error;
        NSDictionary *responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
         if ([responseObject[@"state"] intValue] == 1) {
             self.homePlateArray = (NSMutableArray *)[LXHomePlate objectArrayWithKeyValuesArray:responseObject[@"data"]];
         }
        
        for (LXHomePlate *homePlate in self.homePlateArray) {
            NSString *name = homePlate.moduleName;
            if ([name isEqualToString:@"推荐电影场次"]) {
                [self loadRecommendMovie];
            }else if ([name isEqualToString:@"新影讯"]) {
                [self loadLatestMovie];
            }else if ([name isEqualToString:@"玩吧"]) {
                [self loadPlay];
            }else if ([name isEqualToString:@"神评论"]) {
                [self loadComment];
            }
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
             [self.tableView reloadData];
        });
    });
}

/**
 *  加载推荐电影场次
 */
- (void)loadRecommendMovie {
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    [mgr GET:@"http://devftp.lansum.cn/fishapi/api/Home/IndexMovie" parameters:nil
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         if ([responseObject[@"state"] intValue] == 1) {
             self.recommendMovieArray = (NSMutableArray *)[LXRecommendMovie objectArrayWithKeyValuesArray:responseObject[@"data"]];
         }
         
         dispatch_async(dispatch_get_main_queue(), ^{
             [self.tableView reloadData];
         });
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         
     }];
    
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//        NSString *dataFilePath = [[NSBundle mainBundle] pathForResource:@"recommendMovie" ofType:@"json"];
//        NSData *data = [NSData dataWithContentsOfFile:dataFilePath];
//        NSDictionary *responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
//        if ([responseObject[@"state"] intValue] == 1) {
//            self.recommendMovieArray = (NSMutableArray *)[LXRecommendMovie objectArrayWithKeyValuesArray:responseObject[@"data"]];
//        }
//    });
}

/**
 *  加载新影讯
 */
- (void)loadLatestMovie {
//    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
//    
//    [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:nil
//     success:^(AFHTTPRequestOperation *operation, id responseObject) {
//         if ([responseObject[@"state"] intValue] == 1) {
//             self.latestMovieArray = (NSMutableArray *)[LXNewMovie objectArrayWithKeyValuesArray:responseObject[@"data"]];
//         }
//         [self.tableView reloadData];
//     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//         
//     }];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *dataFilePath = [[NSBundle mainBundle] pathForResource:@"newMovie" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:dataFilePath];
        NSDictionary *responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if ([responseObject[@"state"] intValue] == 1) {
            self.latestMovieArray = (NSMutableArray *)[LXNewMovie objectArrayWithKeyValuesArray:responseObject[@"data"]];
        }
    });
}

/**
 *  加载玩吧
 */
- (void)loadPlay {
//        AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
//    
//        [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:nil
//         success:^(AFHTTPRequestOperation *operation, id responseObject) {
//             if ([responseObject[@"state"] intValue] == 1) {
//                 self.playArray = (NSMutableArray *)[LXShow objectArrayWithKeyValuesArray:responseObject[@"data"]];
//             }
//             [self.tableView reloadData];
//         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//    
//         }];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *dataFilePath = [[NSBundle mainBundle] pathForResource:@"play" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:dataFilePath];
        NSDictionary *responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if ([responseObject[@"state"] intValue] == 1) {
            self.playArray = (NSMutableArray *)[LXShow objectArrayWithKeyValuesArray:responseObject[@"data"]];
        }
    });
}

/**
 *  加载神评论数据
 */
- (void)loadComment {
//    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
//
//    [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:nil
//     success:^(AFHTTPRequestOperation *operation, id responseObject) {
//         if ([responseObject[@"state"] intValue] == 1) {
//             self.commentArray = (NSMutableArray *)[LXComment objectArrayWithKeyValuesArray:responseObject[@"data"]];
//         }
//         [self.tableView reloadData];
//     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//
//     }];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *dataFilePath = [[NSBundle mainBundle] pathForResource:@"comment" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:dataFilePath];
        NSDictionary *responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if ([responseObject[@"state"] intValue] == 1) {
            self.commentArray = (NSMutableArray *)[LXComment objectArrayWithKeyValuesArray:responseObject[@"data"]];
        }
    });
}

#pragma mark - UIScrollViewDelegate代理方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGFloat offsetY = scrollView.contentOffset.y + scrollView.contentInset.top;
    CGFloat scale = offsetY / scrollView.frame.size.height;
    scale = MIN(scale, 1);
    self.bgScrollView.transform = CGAffineTransformMakeScale(MAX(scale/2 + 1, 1), MAX(scale/2 + 1, 1));
    self.visualEffectView.alpha = scale;
    if (offsetY <= (scrollView.frame.size.height + 10)) {
        scrollView.pagingEnabled = YES;
    }else {
        scrollView.pagingEnabled = NO;
    }
    
    UIColor * color = NavBarBackgroundColour;
    if (offsetY > scrollView.frame.size.height - 20) {
        [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:MinNavBarAlpha]];
    } else {
        [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:0]];
    }
}

#pragma mark - UITableViewDataSource数据源方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.homePlateArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    LXHomePlate *homePlate = self.homePlateArray[section];
    // 普通板块
    if (homePlate.moduleType.intValue == 1) {
        NSString *name = homePlate.moduleName;
        if ([name isEqualToString:@"推荐电影场次"]) {
            return 1;
        }else if ([name isEqualToString:@"新影讯"]) {
            return self.latestMovieArray.count;
        }else if ([name isEqualToString:@"玩吧"]) {
            return self.playArray.count;
        }else if ([name isEqualToString:@"神评论"]) {
            return self.commentArray.count;
        }else {
            return 0;
        }
    }else if (homePlate.moduleType.intValue == 2){ // 广告板块
        return 1;
    }else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    LXHomePlate *homePlate = self.homePlateArray[indexPath.section];
    // 普通板块
    if (homePlate.moduleType.intValue == 1) {
        NSString *name = homePlate.moduleName;
        if ([name isEqualToString:@"推荐电影场次"]) {
            LXRecommendMovieCell *cell = [tableView dequeueReusableCellWithIdentifier:recommendMovieCellID];
            cell.recommendMovieArray = self.recommendMovieArray;
            cell.backgroundColor = HomeCellBackgroundColour;
            // 推荐电影场次cell禁止选中
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.delegate = self;
            return cell;
        }else if ([name isEqualToString:@"新影讯"]) {
            LXNewMovieCell *cell = [tableView dequeueReusableCellWithIdentifier:latestMovieCellID];
            cell.movieInfo = self.latestMovieArray[indexPath.row];
            cell.backgroundColor = HomeCellBackgroundColour;
            UIView *selectView = [[UIView alloc] init];
            selectView.backgroundColor = HomeCellSeclectBackgroundColour;
            cell.selectedBackgroundView = selectView;
            return cell;
        }else if ([name isEqualToString:@"玩吧"]) {
            LXShowCell *cell = [tableView dequeueReusableCellWithIdentifier:showCellID];
            cell.show = self.playArray[indexPath.row];
            cell.backgroundColor = HomeCellBackgroundColour;
            UIView *selectView = [[UIView alloc] init];
            selectView.backgroundColor = HomeCellSeclectBackgroundColour;
            cell.selectedBackgroundView = selectView;
            return cell;
        }else if ([name isEqualToString:@"神评论"]) {
            LXCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:commentCellID];
            cell.comment = self.commentArray[indexPath.row];
            cell.backgroundColor = HomeCellBackgroundColour;
            UIView *selectView = [[UIView alloc] init];
            selectView.backgroundColor = HomeCellSeclectBackgroundColour;
            cell.selectedBackgroundView = selectView;
            return cell;
        }else {
            return nil;
        }
    }else if (homePlate.moduleType.intValue == 2){ // 广告板块
        LXAdvertCell *cell = [tableView dequeueReusableCellWithIdentifier:advertCellID];
        LXAdvert *advert = [[LXAdvert alloc] init];
        advert.imageUrl = homePlate.imageUrl;
        advert.url = homePlate.url;
        cell.advert = advert;
        return cell;
    }else {
        return nil;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    LXHomePlate *homePlate = self.homePlateArray[indexPath.section];
    // 普通板块
    if (homePlate.moduleType.intValue == 1) {
        NSString *name = homePlate.moduleName;
        if ([name isEqualToString:@"推荐电影场次"]) {
            return [self.tableView fd_heightForCellWithIdentifier:recommendMovieCellID cacheByIndexPath:indexPath configuration:^(LXRecommendMovieCell *cell) {
                cell.recommendMovieArray = self.recommendMovieArray;
            }];
        }else if ([name isEqualToString:@"新影讯"]) {
            return [self.tableView fd_heightForCellWithIdentifier:latestMovieCellID cacheByIndexPath:indexPath configuration:^(LXNewMovieCell *cell) {
                cell.movieInfo = self.latestMovieArray[indexPath.row];
            }];
        }else if ([name isEqualToString:@"玩吧"]) {
            return [self.tableView fd_heightForCellWithIdentifier:showCellID cacheByIndexPath:indexPath configuration:^(LXShowCell *cell) {
                cell.show = self.playArray[indexPath.row];
            }];
        }else if ([name isEqualToString:@"神评论"]) {
            return [self.tableView fd_heightForCellWithIdentifier:commentCellID cacheByIndexPath:indexPath configuration:^(LXCommentCell *cell) {
                cell.comment = self.commentArray[indexPath.row];
            }];
        }else {
            return 0;
        }
        
    }else if (homePlate.moduleType.intValue == 2){ // 广告板块
        return [self.tableView fd_heightForCellWithIdentifier:advertCellID cacheByIndexPath:indexPath configuration:^(LXAdvertCell *cell) {
            LXAdvert *advert = [[LXAdvert alloc] init];
            advert.imageUrl = homePlate.imageUrl;
            advert.url = homePlate.url;
            cell.advert = advert;
        }];
    }else {
        return 0;
    }
}

/**
 *  返回headerView
 *
 */
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section  {
    LXHomePlate *homePlate = self.homePlateArray[section];
    // 普通板块
    if (homePlate.moduleType.intValue == 1) {
        return [self headerViewWithName:homePlate.moduleName section:section];
    }else if (homePlate.moduleType.intValue == 2){ // 广告板块
        UIView *view = [[UIView alloc] init];
        return view;
    }else {
        UIView *view = [[UIView alloc] init];
        return view;
    }
    
    return nil;
}

/**
 *  根据板块名字返回对应的headerView
 *
 */
- (LXCellHeaderView *)headerViewWithName:(NSString *)name section:(NSInteger)section{
    LXCellHeader *header = [[LXCellHeader alloc] init];
    
    if ([name isEqualToString:@"推荐电影场次"]) {
        header.imageUrl = @"home_section_recommend";
        header.titleName = name;
    }else if ([name isEqualToString:@"新影讯"]) {
        header.imageUrl = @"home_section_newMovie";
        header.titleName = name;
    }else if ([name isEqualToString:@"玩吧"]) {
        header.imageUrl = @"home_section_play";
        header.titleName = name;
    }else if ([name isEqualToString:@"神评论"]) {
        header.imageUrl = @"home_section_comment";
        header.titleName = name;
    }else {
        return nil;
    }
    
    LXCellHeaderView *headerView = [[LXCellHeaderView alloc] init];
    headerView.backgroundColor = HomeCellBackgroundColour;
    headerView.cellHeader = header;
    headerView.section = section;
    headerView.delegate = self;
    
    return headerView;
}

/**
 *  返回headerView高度
 *
 */
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    LXHomePlate *homePlate = self.homePlateArray[section];
    // 普通板块
    if (homePlate.moduleType.intValue == 1) {
        return 50;
    }else if (homePlate.moduleType.intValue == 2){ // 广告板块
        return 0;
    }else {
        return 0;
    }
}

/**
 *  返回footerView的高度
 *
 */
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    LXHomePlate *homePlate = self.homePlateArray[section];
    // 普通板块
    if (homePlate.moduleType.intValue == 1) {
        return 5;
    }else if (homePlate.moduleType.intValue == 2){ // 广告板块
        return 22;
    }else {
        return 0;
    }
}

#pragma mark - UITableViewDelegate代理方法
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];// 取消选中

    LXHomePlate *homePlate = self.homePlateArray[indexPath.section];
    // 普通板块
    if (homePlate.moduleType.intValue == 1) {
        NSString *name = homePlate.moduleName;
        if ([name isEqualToString:@"推荐电影场次"]) {
            NSLog(@"推荐电影场次");
        }else if ([name isEqualToString:@"新影讯"]) {
            NSLog(@"新影讯");
            [self openHtml:@"movieDetail_old" withDirectory:@"Movie"];
        }else if ([name isEqualToString:@"玩吧"]) {
            NSLog(@"玩吧");
            [self openHtml:@"recreationShow" withDirectory:@"recreation"];
        }else if ([name isEqualToString:@"神评论"]) {
            NSLog(@"神评论");
            [self openHtml:@"deityComment" withDirectory:@"other"];
        }
        
    }else if (homePlate.moduleType.intValue == 2){ // 广告板块
        NSLog(@"广告");
    }
}

#pragma mark - LXSuspendCollectionViewDelegate的代理方法
- (void)suspendCollectionView:(LXSuspendCollectionView *)collectionView suspendType:(LXSuspenditemAction)actionType{
    switch (actionType) {
        case LXSuspenditemActionHot:{
            NSLog(@"热度榜");
            [self openHtml:@"heatNotice" withDirectory:nil];
            break;
        }
        case LXSuspenditemActionPlay:{
            NSLog(@"玩吧");
            [self openHtml:@"recreationShow" withDirectory:@"recreation"];
            break;
        }
        case LXSuspenditemActionComment:
            NSLog(@"神评论");
            [self openHtml:@"deityComment" withDirectory:@"other"];
            break;
        case LXSuspenditemActionNewMovie:{
            NSLog(@"新影讯");
            [self openHtml:@"movie" withDirectory:@"Movie"];
            break;
        }
        default:
            break;
    }
}

#pragma mark - LXAssistiveViewDelegate代理方法
- (void)didSelectedAssistiveView {
    NSLog(@"ticketBtnClicked");
    [self openHtml:@"movie" withDirectory:@"Movie"];
}

#pragma mark - LXCellHeaderViewDelegate代理方法
/**
 *  点击headerView对应的事件
 *
 */
- (void)headerView:(LXCellHeaderView *)headerView diddidSelectSection:(NSInteger)section {
    LXHomePlate *homePlate = self.homePlateArray[section];
    NSString *name = homePlate.moduleName;
    if ([name isEqualToString:@"推荐电影场次"]) {
        [self openHtml:@"movie" withDirectory:@"Movie"];
    }else if ([name isEqualToString:@"新影讯"]) {
        [self openHtml:@"movie" withDirectory:@"Movie"];
    }else if ([name isEqualToString:@"玩吧"]) {
        [self openHtml:@"recreationShow" withDirectory:@"recreation"];
    }else if ([name isEqualToString:@"神评论"]) {
        [self openHtml:@"deityComment" withDirectory:@"other"];
    }
}

#pragma mark - LXRecommendMovieCellDelegate代理方法
- (void)didSelectImage:(LXRecommendMovie *)recommendMovie{
    if (recommendMovie.movieInfoId) {
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"shuizhuyu" ofType:@"bundle"];
        NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
        NSString *path = [bundle pathForResource:@"movieDetail" ofType:@"html" inDirectory:@"Movie"];
        NSString *movieHtmlName = [NSString stringWithFormat:@"%@?MovieInfoId=%d", path, [recommendMovie.movieInfoId intValue]];
        LXWebViewController* webViewController = [[LXWebViewController alloc] initWithUrl:[NSURL URLWithString:movieHtmlName]];
        [self.navigationController pushViewController:webViewController animated:YES];
    }
}

- (void)openHtml:(NSString *)name withDirectory:(NSString *)directory{
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"shuizhuyu" ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSString *path = nil;
    
    if (directory) {
        path = [bundle pathForResource:name ofType:@"html" inDirectory:directory];
        NSLog(@"%@", path);
    }else {
        path = [bundle pathForResource:name ofType:@"html"];
        NSLog(@"%@", path);
    }
    
    LXWebViewController* webViewController = [[LXWebViewController alloc] initWithUrl:[NSURL URLWithString:path]];
    [self.navigationController pushViewController:webViewController animated:YES];
}

#pragma mark - YMCitySelectDelegate代理方法
-(void)ym_ymCitySelectCityName:(NSString *)cityName{
    [self.locationBtn setTitle:cityName forState:UIControlStateNormal];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

@end
