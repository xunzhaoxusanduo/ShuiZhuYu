//
//  LXShow.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/28.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LXShow : NSObject

// 标题的背景
@property (nonatomic, copy)NSString *titleBgImage;
// 标题
@property (nonatomic, copy)NSString *title;
// 海报图片
@property (nonatomic, copy)NSString *posterImageUrl;
// 点赞和评论数的背景图片
@property (nonatomic, copy)NSString *statusBgImage;
// 点赞
@property (nonatomic, copy)NSString *attitude;
// 评论
@property (nonatomic, copy)NSString *comment;
// 跳转的链接
@property (nonatomic, copy)NSString *url;

@end
