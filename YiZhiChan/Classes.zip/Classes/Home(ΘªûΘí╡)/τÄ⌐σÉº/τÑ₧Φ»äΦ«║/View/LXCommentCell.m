//
//  LXCommentCell.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/30.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXCommentCell.h"
#import "Masonry.h"
#import "Macros.h"
#import "UIImage+FEBoxBlur.h"
#import "LXComment.h"
#import "LXPhoto.h"

#define PhotoCounts 3
#define PhotoViewHeight 80

@interface LXCommentCell ()

@property (nonatomic, strong)UILabel *title;
@property (nonatomic, strong)UILabel *detail;
@property (nonatomic, strong)NSMutableArray *photoViewArray;
// 分割线
@property (nonatomic, strong)UIView *divView;

@end

@implementation LXCommentCell

- (NSMutableArray *)photoViewArray {
    if (_photoViewArray == nil) {
        _photoViewArray = [NSMutableArray array];
    }
    
    return _photoViewArray;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setupSubViews];
        [self setupAutoLayout];
    }
    
    return  self;
}

- (void)setupSubViews {
    UILabel *title = [[UILabel alloc] init];
    title.textColor = [UIColor whiteColor];
    title.font = [UIFont systemFontOfSize:TitleFontSize];
    title.numberOfLines = 1;
    [self.contentView addSubview:title];
    self.title = title;
    
    CGFloat preferMaxWidth = [UIScreen mainScreen].bounds.size.width - 10*2;
    
    UILabel *detail = [[UILabel alloc] init];
    detail.textColor = [UIColor whiteColor];
    detail.font = [UIFont systemFontOfSize:DetailFontSize];
    detail.numberOfLines = 0;
    detail.preferredMaxLayoutWidth = preferMaxWidth;
    [self.contentView addSubview:detail];
    self.detail = detail;
    
    for (int i = 0; i < PhotoCounts; i++) {
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.contentView addSubview:imageView];
        [self.photoViewArray addObject:imageView];
    }
}

- (void)setupAutoLayout {
    WS(weakSelf);
    int padding = 10;
    
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.mas_equalTo(padding);
        make.right.equalTo(weakSelf.mas_right).offset(-padding);
        make.height.mas_equalTo(20);
    }];
    
    [self.detail mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.title.mas_bottom).offset(padding);
        make.left.mas_equalTo(padding);
        make.right.equalTo(weakSelf.mas_right).offset(-padding);
//        make.width.mas_equalTo(100);
    }];
    
    __block UIImageView *lastImageView = nil;
    for (int i = 0; i < PhotoCounts; i++) {
        UIImageView *imageView = self.photoViewArray[i];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(weakSelf.detail.mas_bottom).offset(padding);
            make.bottom.equalTo(weakSelf.contentView.mas_bottom).offset(-padding);
            make.height.mas_equalTo(PhotoViewHeight);
            if (i == 0) {
                make.left.equalTo(weakSelf.contentView.mas_left).offset(padding);
            }else if (i == 1) {
                make.width.equalTo(lastImageView.mas_width);
                make.left.equalTo(lastImageView.mas_right).offset(padding);
            }else if (i == 2) {
                make.width.equalTo(lastImageView.mas_width);
                make.left.equalTo(lastImageView.mas_right).offset(padding);
                make.right.equalTo(weakSelf.contentView.mas_right).offset(-padding);
            }
        }];
        lastImageView = imageView;
    }
}

- (void)setComment:(LXComment *)comment {
    _comment = comment;
    self.title.text = comment.title;
    self.detail.text = comment.detail;
    
    for (int i = 0; i < PhotoCounts; i++) {
        UIImageView *imageView = self.photoViewArray[i];
        LXPhoto *photo = comment.photoArray[i];
        UIImage *image = [UIImage imageNamed:photo.imageUrl];
        if (image.size.height > PhotoViewHeight) {
            CGSize size = CGSizeMake(image.size.width * (PhotoViewHeight / image.size.height), PhotoViewHeight);
            image = [image reSizeImage:image toSize:size];
        }
        imageView.image = image;
    }
}

// 自绘分割线
- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetStrokeColorWithColor(context, RGBA(255, 255, 255, 0.15).CGColor);
    CGContextStrokeRect(context, CGRectMake(0, rect.size.height - 1, rect.size.width, 1));
}

@end
