//
//  LXPhoto.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/30.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LXPhoto : NSObject

@property (nonatomic, strong)NSString *imageUrl;

@end
