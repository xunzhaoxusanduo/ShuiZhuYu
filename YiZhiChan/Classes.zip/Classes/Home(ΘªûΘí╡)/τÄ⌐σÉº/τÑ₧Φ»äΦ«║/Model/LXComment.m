//
//  LXComment.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/30.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXComment.h"
#import "MJExtension.h"
#import "LXPhoto.h"

@implementation LXComment

- (NSDictionary *)objectClassInArray {
    return @{@"photoArray": [LXPhoto class]};
}

@end
