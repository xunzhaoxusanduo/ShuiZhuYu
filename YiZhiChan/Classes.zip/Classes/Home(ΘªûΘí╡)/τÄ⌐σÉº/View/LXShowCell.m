//
//  LXShowCell.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXShowCell.h"
#import "Masonry.h"
#import "Macros.h"
#import "LXShow.h"
#import "UIImage+FEBoxBlur.h"

@interface LXShowCell ()

// 标题的背景
@property (nonatomic, strong)UIView *titleBgView;
// 标题
@property (nonatomic, strong)UILabel *title;
// 海报图片
@property (nonatomic, strong)UIImageView *posterImage;
// 点赞和评论数的背景图片
@property (nonatomic, strong)UIImageView *statusBgImageView;
// 点赞
@property (nonatomic, strong)UIButton *attitudeBtn;
// 评论
@property (nonatomic, strong)UIButton *commentBtn;

@end

@implementation LXShowCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setupSubViews];
        [self setupAutoLayout];
    }
    
    return  self;
}

- (void)setupSubViews {
    // 标题的背景
    UIView *titleBgView = [[UIView alloc] init];
    titleBgView.backgroundColor = RGBA(0, 0, 0, 0.4);
    [self.contentView addSubview:titleBgView];
    self.titleBgView = titleBgView;
    
    // 标题
    UILabel *title = [[UILabel alloc] init];
    title.textAlignment = NSTextAlignmentCenter;
    title.textColor = [UIColor whiteColor];
    title.font = [UIFont systemFontOfSize:TitleFontSize];
    [self.titleBgView addSubview:title];
    self.title = title;
    
    // 海报图片
    UIImageView *posterImage = [[UIImageView alloc] init];
    posterImage.contentMode = UIViewContentModeScaleAspectFill;
    [self.contentView addSubview:posterImage];
    self.posterImage = posterImage;
    
//    // 点赞和评论数的背景图片
//    UIImageView *statusBgImageView = [[UIImageView alloc] init];
//    [self.contentView addSubview:statusBgImageView];
//    self.statusBgImageView = statusBgImageView;
    
//    // 点赞
//    UIButton *attitudeBtn = [[UIButton alloc] init];
////    [attitudeBtn setImage:[UIImage imageNamed:@"tabbar-icon-play"] forState:UIControlStateNormal];
//    [self.statusBgImageView addSubview:attitudeBtn];
//    self.attitudeBtn = attitudeBtn;
//    
//    // 评论
//    UIButton *commentBtn = [[UIButton alloc] init];
////    [commentBtn setImage:[UIImage imageNamed:@"tabbar-icon-play"] forState:UIControlStateNormal];
//    [self.statusBgImageView addSubview:commentBtn];
//    self.commentBtn = commentBtn;
}

- (void)setupAutoLayout {
    int padding = 10;
    WS(weakSelf);
    
    // 标题的背景
    [self.titleBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.and.right.equalTo(weakSelf.contentView);
        make.height.mas_equalTo(40);
    }];
    
    //标题
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(weakSelf.titleBgView);
    }];
    
    // 海报图片
    [self.posterImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.titleBgView.mas_bottom);
        make.left.and.right.equalTo(weakSelf.contentView);
        make.width.equalTo(weakSelf.contentView.mas_width);
        make.bottom.equalTo(weakSelf.contentView.mas_bottom);
    }];
    
//    // 点赞和评论数的背景图片
//    [self.statusBgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.size.mas_equalTo(CGSizeMake(150, 50));
//        make.right.equalTo(weakSelf.posterImage.mas_right);
//        make.bottom.equalTo(weakSelf.posterImage.mas_bottom).offset(-5);
//    }];
//    
//    // 点赞
//    [self.attitudeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.and.left.equalTo(weakSelf.statusBgImageView).offset(padding);
//        make.bottom.equalTo(weakSelf.statusBgImageView).offset(-padding);
//        make.right.equalTo(weakSelf.commentBtn.mas_left).offset(-padding);
//        make.width.equalTo(weakSelf.commentBtn.mas_width);
//    }];
//    
//    // 评论
//    [self.commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(weakSelf.statusBgImageView).offset(padding);
//        make.bottom.equalTo(weakSelf.statusBgImageView).offset(-padding);
//        make.right.equalTo(weakSelf.statusBgImageView.mas_right).offset(-padding);
//        make.width.equalTo(weakSelf.attitudeBtn.mas_width);
//    }];
}

- (void)setShow:(LXShow *)show {
    _show = show;
    self.title.text = show.title;
    
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    UIImage *image = [UIImage imageNamed:show.posterImageUrl];
    if (image.size.width > screenWidth) {
        CGSize size = CGSizeMake(screenWidth, image.size.height * (screenWidth / image.size.width));
        image = [image reSizeImage:image toSize:size];
    }
    self.posterImage.image = image;
    
//    self.statusBgImageView.image = [UIImage imageNamed:show.statusBgImage];
//    [self.attitudeBtn setTitle:show.attitude forState:UIControlStateNormal];
//    [self.commentBtn setTitle:show.comment forState:UIControlStateNormal];
    
//    self.statusBgImageView.image = [UIImage resizedImageWithName:@"statusBg" left:0.8 top:0.5];
}

















@end
