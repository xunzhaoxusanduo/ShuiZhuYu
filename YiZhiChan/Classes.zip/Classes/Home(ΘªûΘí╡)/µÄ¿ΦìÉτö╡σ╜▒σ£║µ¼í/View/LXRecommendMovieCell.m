//
//  LXRecommendMovieCell.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXRecommendMovieCell.h"
#import "LXRecommendMovieView.h"
#import "LXCellHeaderView.h"
#import "Masonry.h"
#import "Macros.h"
#import "LXCellHeader.h"

#define MovieCounts         6
#define MovieViewHeight     200     // 每个电影view的高度
#define MovieViewPadding    5      // 每个电影view之间的间距

@interface LXRecommendMovieCell ()

@property (nonatomic, strong)LXCellHeaderView *headerView;
@property (nonatomic, strong)UIView *movieBgView;
@property (nonatomic, strong)NSMutableArray *movieArray;

@end

@implementation LXRecommendMovieCell

- (NSMutableArray *)movieArray {
    if (_movieArray == nil) {
        _movieArray = [NSMutableArray array];
    }
    
    return  _movieArray;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setupSubViews];
        [self setupAutoLayout];
    }
    
    return  self;
}

- (void)setupSubViews {
    self.backgroundColor = HomeCellBackgroundColour;
    
//    LXCellHeaderView *headerView = [[LXCellHeaderView alloc] init];
//    [self.contentView addSubview:headerView];
//    self.headerView = headerView;
    
    UIView *movieBgView = [[UIView alloc] init];
    movieBgView.backgroundColor = [UIColor clearColor];
    [self.contentView addSubview:movieBgView];
    self.movieBgView = movieBgView;
    
    for (int i = 0; i < MovieCounts; i++) {
        LXRecommendMovieView *movieView = [[LXRecommendMovieView alloc] init];
        movieView.tag = i;
        [self.movieArray addObject:movieView];
        [self.movieBgView addSubview:movieView];
        
        UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
        [movieView addGestureRecognizer:tapGestureRecognizer];
    }
}

- (void)handleTapGesture:(UITapGestureRecognizer *)sender {
    if ([sender.view isKindOfClass:[LXRecommendMovieView class]]) {
        for (int i = 0; i < [self.movieArray count]; i++) {
            LXRecommendMovieView *movieView = self.movieArray[i];
            if (movieView.tag == sender.view.tag) {
                if ([self.delegate respondsToSelector:@selector(didSelectImage:)]) {
                    [self.delegate didSelectImage:self.recommendMovieArray[i]];
                }
            }
        }
    }
}

- (void)setupAutoLayout {
    WS(weakSelf);
    
//    [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.and.left.and.right.equalTo(self.contentView);
//        make.height.mas_equalTo(50);
//    }];
    
    [self.movieBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(weakSelf.contentView);
    }];
    
//    LXRecommendMovieView *movieView1 = (LXRecommendMovieView *)self.movieArray[0];
//    LXRecommendMovieView *movieView2 = (LXRecommendMovieView *)self.movieArray[1];
//    LXRecommendMovieView *movieView3 = (LXRecommendMovieView *)self.movieArray[2];
//    
//    [movieView1 mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.divView.mas_top).offset(MovieViewPadding);
//        make.left.equalTo(self.contentView.mas_left).offset(MovieViewPadding);
//        make.right.equalTo(movieView2.mas_left).offset(-MovieViewPadding);
//        make.width.equalTo(movieView2);
//        make.height.mas_equalTo(MovieViewHeight);
//    }];
//    
//    [movieView2 mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.divView.mas_top).offset(MovieViewPadding);
////        make.left.equalTo(self.movieBgView).offset(MovieViewPadding);
//        make.right.equalTo(movieView3.mas_left).offset(-MovieViewPadding);
//        make.width.equalTo(movieView3);
//        make.height.mas_equalTo(MovieViewHeight);
//    }];
//    
//    [movieView3 mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.divView.mas_top).offset(MovieViewPadding);
//        //        make.left.equalTo(self.movieBgView).offset(MovieViewPadding);
//        make.right.equalTo(self.contentView.mas_right).offset(-MovieViewPadding);
//        make.width.equalTo(movieView1);
//        make.height.mas_equalTo(MovieViewHeight);
//    }];
    
    __block LXRecommendMovieView *lastMovieView = nil;
    
    for (__block int i = 0; i < [self.movieArray count]; i++) {
        LXRecommendMovieView *movieView = (LXRecommendMovieView *)self.movieArray[i];
        
        [movieView mas_makeConstraints:^(MASConstraintMaker *make) {
            //设置高度
            make.height.mas_equalTo(MovieViewHeight);

            //当是左边一列的时候
            if (i%3 == 0) {
                make.left.equalTo(self.movieBgView.mas_left).offset(MovieViewPadding);
            }else{//不是中间列的时候
                make.width.equalTo(lastMovieView.mas_width);
                make.left.equalTo(lastMovieView.mas_right).offset(MovieViewPadding);
            }
            
            //当是最右边列的时候
            if (i%3 == 2) {
                make.right.equalTo(self.movieBgView.mas_right).offset(-MovieViewPadding);
            }
            
            //当是第1行的时候
            if (i/3 == 0) {
                make.top.equalTo(self.movieBgView.mas_top).offset(MovieViewPadding);
            }else if (i/3 == 1) {
                make.top.equalTo(self.movieBgView.mas_top).offset(2*MovieViewPadding + MovieViewHeight);
                make.bottom.equalTo(self.movieBgView.mas_bottom).offset(-MovieViewPadding);
            }
        }];
        
        lastMovieView = movieView;
    }
    
//    __block LXRecommendMovieView *lastMovieView = nil;
//    // 每行3个
//    int num = 3;
//    
//    for (int i = 0; i < [self.movieArray count]; i++) {
//        LXRecommendMovieView *movieView = (LXRecommendMovieView *)self.movieArray[i];
//        // 添加约束
//        [movieView mas_makeConstraints:^(MASConstraintMaker *make) {
//            // 给个高度约束
//            make.height.mas_equalTo(MovieViewHeight);
//            
//            // 1. 判断是否存在上一个view
//            if (lastMovieView) {
//                // 存在的话宽度与上一个宽度相同
//                make.width.equalTo(lastMovieView);
//            } else {
//                // 否则计算宽度  ！！！此处的判断条件是为了避免 最后一列约束冲突
//                /**
//                 *  这里可能大家会问 为什么上面我说最后一列会有冲突？
//                 *  如果不添加判断的话会造成：
//                 *  1添加了宽度约束 2所有列加了左侧约束 第3步给 最后一列添加了右侧约束
//                 *  这里最后一列既有左侧约束又有右侧约束还有宽度约束 会造成约束冲突
//                 *  所以这里添加宽度时将最后一列剔除
//                 */
//                if (i % num != 0) {
//                    make.width.mas_equalTo((movieView.superview.frame.size.width - (num + 1)* MovieViewPadding)/4);
//                }
//            }
//            // 2. 判断是否是第一列
//            if (i % num == 0) {
//                // 一：是第一列时 添加左侧与父视图左侧约束
//                make.left.mas_equalTo(movieView.superview).offset(MovieViewPadding);
//            } else {
//                // 二： 不是第一列时 添加左侧与上个view左侧约束
//                make.left.mas_equalTo(movieView.mas_right).offset(MovieViewPadding);
//            }
//            // 3. 判断是否是最后一列 给最后一列添加与父视图右边约束
//            if (i % num == (num - 1)) {
//                make.right.mas_equalTo(movieView.superview).offset(-MovieViewPadding);
//            }
//            // 4. 判断是否为第一列
//            if (i / num == 0) {
//                // 第一列添加顶部约束
//                make.top.mas_equalTo(movieView.superview).offset(MovieViewPadding*10);
//            } else {
//                // 其余添加顶部约束 intes*10 是我留出的距顶部高度
//                make.top.mas_equalTo(MovieViewPadding * 10 + ( i / num )* (80 + MovieViewPadding));
//            }
//            
//        }];
//        // 每次循环结束 此次的View为下次约束的基准
//        lastMovieView = movieView;
//    }
}

- (void)setRecommendMovieArray:(NSArray *)recommendMovieArray {
    _recommendMovieArray = recommendMovieArray;
    
    for (int i = 0; i < [self.recommendMovieArray count]; i++) {
        LXRecommendMovieView *movieView = (LXRecommendMovieView *)self.movieArray[i];
        movieView.recommendMovie = recommendMovieArray[i];
    }
}

@end
