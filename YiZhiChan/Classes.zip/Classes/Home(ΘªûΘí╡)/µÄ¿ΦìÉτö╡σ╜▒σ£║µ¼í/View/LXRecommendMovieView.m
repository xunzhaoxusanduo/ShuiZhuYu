//
//  LXRecommendMovieView.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXRecommendMovieView.h"
#import "LXRecommendMovie.h"
#import "Masonry.h"
#import "UIImageView+WebCache.h"
#import "Macros.h"
#import "UIImage+FEBoxBlur.h"

#define ImageRadio              0.7
#define GradeViewWidthAndHeigth 30
#define ARC4RANDOM_MAX          0x100000000
#define ImageWidth              100
#define ImageHeight             200

@interface LXRecommendMovieView ()

@property (nonatomic, strong)UIImageView *imageView;
@property (nonatomic, strong)UILabel *movenameLbl;
@property (nonatomic, strong)UIButton *gradeBtn;

@end

@implementation LXRecommendMovieView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupSubViews];
        [self setupAutoLayout];
    }
    
    return self;
}

- (instancetype)init{
    if (self = [super init]) {
        [self setupSubViews];
        [self setupAutoLayout];
    }
    
    return self;
}

- (void)setupSubViews {
//    self.backgroundColor = [UIColor grayColor];
    
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.userInteractionEnabled = YES;
    [self addSubview:imageView];
    self.imageView = imageView;
    
    UIButton *gradeBtn = [[UIButton alloc] init];
    gradeBtn.layer.cornerRadius = GradeViewWidthAndHeigth/2;
    gradeBtn.layer.masksToBounds = YES;
    gradeBtn.backgroundColor = RGB(251, 84, 9);
    gradeBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [self addSubview:gradeBtn];
    self.gradeBtn = gradeBtn;
    
    UILabel *movenameLbl = [[UILabel alloc] init];
    movenameLbl.textAlignment = NSTextAlignmentCenter;
    movenameLbl.textColor = [UIColor whiteColor];
    movenameLbl.font = [UIFont systemFontOfSize:15];
    [self addSubview:movenameLbl];
    self.movenameLbl = movenameLbl;
}

- (void)setupAutoLayout {
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.and.right.equalTo(self);
        make.height.equalTo(self).multipliedBy(ImageRadio);
    }];
    
    [self.gradeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(GradeViewWidthAndHeigth, GradeViewWidthAndHeigth));
        make.centerX.equalTo(self.mas_centerX);
        make.centerY.equalTo(self.imageView.mas_bottom);
    }];
    
    [self.movenameLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.bottom.and.right.equalTo(self);
        make.top.equalTo(self.gradeBtn).offset(20);
    }];
}

- (void)setRecommendMovie:(LXRecommendMovie *)recommendMovie {
    _recommendMovie = recommendMovie;
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:recommendMovie.cover] placeholderImage:[UIImage imageNamed:@"placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        if (image.size.height > ImageHeight) {
            CGSize size = CGSizeMake(image.size.width * (ImageHeight / image.size.height), ImageHeight);
            image = [image reSizeImage:image toSize:size];
        }
        self.imageView.image = image;
    }];
    
//    if (recommendMovie.rating) {
//    }
//    NSString *str = [NSString stringWithFormat:@"%0.1f", [recommendMovie.rating floatValue]];
//    NSMutableAttributedString *attributedStr = [[NSMutableAttributedString alloc] initWithString:str];
    
    int num1 = (float)[self getRandomNumber:6 to:9];
    int num12 = (float)[self getRandomNumber:0 to:9];
    NSString *str = [NSString stringWithFormat:@"%d.%d", num1, num12];

    [self.gradeBtn setTitle:str forState:UIControlStateNormal];
    self.movenameLbl.text = recommendMovie.movieName;
}

- (int)getRandomNumber:(int)from to:(int)to {
    return (int)(from + (arc4random() % (to - from + 1)));
}

@end
