//
//  LXAdvertCell.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LXAdvert;

@interface LXAdvertCell : UITableViewCell

@property (nonatomic, strong)LXAdvert *advert;

@end
