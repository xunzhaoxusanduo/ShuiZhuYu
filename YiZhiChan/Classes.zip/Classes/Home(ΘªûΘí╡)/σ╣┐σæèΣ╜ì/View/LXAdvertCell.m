//
//  LXAdvertCell.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXAdvertCell.h"
#import "Masonry.h"
#import "LXAdvert.h"
#import "UIImage+FEBoxBlur.h"

@interface LXAdvertCell ()

@property (nonatomic, strong)UIImageView *imageView1;

@end

@implementation LXAdvertCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setupSubViews];
        [self setupAutoLayout];
    }
    
    return  self;
}

- (void)setupSubViews {
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.contentView addSubview:imageView];
    self.imageView1 = imageView;
    
}

- (void)setupAutoLayout {
    [self.imageView1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.and.right.equalTo(self.contentView);
//        self.heightConstraint = make.height.mas_equalTo(500);
        make.bottom.lessThanOrEqualTo(self.contentView.mas_bottom);
    }];
}

- (void)setAdvert:(LXAdvert *)advert {
    _advert = advert;
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    UIImage *image = [UIImage imageNamed:advert.imageUrl];
    if (image.size.width > screenWidth) {
        CGSize size = CGSizeMake(screenWidth, image.size.height * (screenWidth / image.size.width));
        image = [image reSizeImage:image toSize:size];
    }
    self.imageView1.image = image;
}

@end
