//
//  LXAdvert.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/28.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LXAdvert : NSObject

@property (nonatomic, copy)NSString *imageUrl;
// 跳转的链接
@property (nonatomic, copy)NSString *url;

@end
