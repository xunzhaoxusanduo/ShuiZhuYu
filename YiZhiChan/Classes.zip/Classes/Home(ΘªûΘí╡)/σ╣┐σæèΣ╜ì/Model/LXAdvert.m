//
//  LXAdvert.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/28.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXAdvert.h"

@implementation LXAdvert

@end
