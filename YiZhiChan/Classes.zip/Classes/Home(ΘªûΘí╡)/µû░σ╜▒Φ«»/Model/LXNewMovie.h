//
//  LXNewMovie.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LXNewMovie : NSObject

// 海报图片
@property (nonatomic, copy)NSString *posterImageUrl;
// 电影名
@property (nonatomic, copy)NSString *movieName;
// 电影评分
@property (nonatomic, copy)NSNumber *grade;
// 电影类型
@property (nonatomic, copy)NSNumber *movieType;
// 导演名字
@property (nonatomic, copy)NSString *directorName;
// 上映日期
@property (nonatomic, copy)NSString *releaseDate;
// 电影简介
@property (nonatomic, copy)NSString *movieNotes;
// 跳转的链接
@property (nonatomic, copy)NSString *url;

@end
