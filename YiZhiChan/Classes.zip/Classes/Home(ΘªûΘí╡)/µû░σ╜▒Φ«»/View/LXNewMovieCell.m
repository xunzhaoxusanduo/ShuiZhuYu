//
//  LXNewMovieCell.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXNewMovieCell.h"
#import "Masonry.h"
#import "Macros.h"
#import "LXNewMovie.h"
#import "UIImage+FEBoxBlur.h"

#define PosterImageWidth    80

@interface LXNewMovieCell ()

// 海报图片
@property (nonatomic, strong)UIImageView *posterImageView;
// 电影名
@property (nonatomic, strong)UILabel *movieNameLbl;
// 电影评分
@property (nonatomic, strong)UIButton *gradeBtn;
// 电影类型
@property (nonatomic, strong)UIImageView *movieType;
// 导演名字
@property (nonatomic, strong)UILabel *directorNameLbl;
// 上映日期
@property (nonatomic, strong)UILabel *releaseDateLbl;
// 电影简介
@property (nonatomic, strong)UILabel *movieNotesLbl;
// 分割线
@property (nonatomic, strong)UIView *divView;

@end

@implementation LXNewMovieCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setupSubViews];
        [self setupAutoLayout];
    }
    
    return  self;
}

- (void)setupSubViews {
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    // 海报图片
    UIImageView *posterImageView = [[UIImageView alloc] init];
    posterImageView.contentMode = UIViewContentModeScaleAspectFill;
    [self.contentView addSubview:posterImageView];
    self.posterImageView = posterImageView;
    
    // 电影名
    UILabel *movieNameLbl = [[UILabel alloc] init];
    movieNameLbl.textColor = [UIColor whiteColor];
    movieNameLbl.font = [UIFont boldSystemFontOfSize:TitleFontSize];
    [self.contentView addSubview:movieNameLbl];
    self.movieNameLbl = movieNameLbl;
    
    // 电影评分
    UIButton *gradeBtn = [[UIButton alloc] init];
    gradeBtn.userInteractionEnabled = NO;
    gradeBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [gradeBtn setBackgroundImage:[UIImage resizedImageWithName:@"main_badge"] forState:UIControlStateNormal];
    [self.contentView addSubview:gradeBtn];
    self.gradeBtn = gradeBtn;
    
    // 电影类型
    UIImageView *movieType = [[UIImageView alloc] init];
    movieType.contentMode = UIViewContentModeScaleAspectFit;
    movieType.image = [UIImage imageNamed:@"iMAX3D"];
    [self.contentView addSubview:movieType];
    self.movieType = movieType;
    
    // 导演名字
    UILabel *directorNameLbl = [[UILabel alloc] init];
    directorNameLbl.textColor = [UIColor whiteColor];
    directorNameLbl.font = [UIFont systemFontOfSize:DetailFontSize];
    [self.contentView addSubview:directorNameLbl];
    self.directorNameLbl = directorNameLbl;
    
    // 上映日期
    UILabel *releaseDateLbl = [[UILabel alloc] init];
    releaseDateLbl.textColor = [UIColor whiteColor];
    releaseDateLbl.font = [UIFont systemFontOfSize:DetailFontSize];
    [self.contentView addSubview:releaseDateLbl];
    self.releaseDateLbl = releaseDateLbl;
    
    // 电影简介
    CGFloat preferMaxWidth = [UIScreen mainScreen].bounds.size.width*0.7;
    UILabel *movieNotesLbl = [[UILabel alloc] init];
    movieNotesLbl.textColor = [UIColor whiteColor];
    movieNotesLbl.font = [UIFont systemFontOfSize:13];
    movieNotesLbl.numberOfLines = 2;
    movieNotesLbl.preferredMaxLayoutWidth = preferMaxWidth;
    [self.contentView addSubview:movieNotesLbl];
    self.movieNotesLbl = movieNotesLbl;
    
//    // 分割线
//    UIView *divView = [[UIView alloc] init];
//    divView.backgroundColor = RGBA(1, 1, 1, 1);
//    [self.contentView addSubview:divView];
//    self.divView = divView;
}

- (void)setupAutoLayout {
    WS(weakSelf);
    int padding = 10;
    
    // 海报图片
    [self.posterImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.equalTo(weakSelf.contentView).offset(padding);
        make.right.equalTo(weakSelf.movieNameLbl.mas_left).offset(-padding);
        make.width.mas_equalTo(PosterImageWidth);
        make.bottom.equalTo(weakSelf.contentView.mas_bottom).offset(-padding);
    }];
    
    // 电影名
    [self.movieNameLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.posterImageView.mas_top).offset(padding);
        make.left.equalTo(weakSelf.posterImageView.mas_right).offset(padding);
        make.height.mas_equalTo(15);
    }];
    
    // 电影评分
    [self.gradeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(weakSelf.movieNameLbl.mas_centerY);
        make.left.equalTo(weakSelf.movieNameLbl.mas_right).offset(padding/2);
        make.height.mas_equalTo(22);
        make.width.mas_equalTo(50);
    }];
    
    // 电影类型
    [self.movieType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(weakSelf.movieNameLbl.mas_centerY);
        make.left.equalTo(weakSelf.gradeBtn.mas_right).offset(padding);
        make.height.mas_equalTo(15);
        make.width.mas_equalTo(60);
    }];
    
    // 导演名字
    [self.directorNameLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.movieNameLbl.mas_bottom).offset(padding);
        make.left.equalTo(weakSelf.posterImageView.mas_right).offset(padding);
    }];
    
    // 上映日期
    [self.releaseDateLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.movieNameLbl.mas_bottom).offset(padding);
        make.left.equalTo(weakSelf.directorNameLbl.mas_right).offset(padding);
    }];
    
    // 电影简介
    [self.movieNotesLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.posterImageView.mas_right).offset(padding);
        make.right.equalTo(weakSelf.contentView.mas_right).offset(-padding);
        make.top.equalTo(weakSelf.posterImageView.mas_bottom).offset(-31);
    }];
    
//    // 分割线
//    [self.divView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(weakSelf.contentView.mas_left);
//        make.bottom.equalTo(weakSelf.contentView.mas_bottom);
//        make.height.mas_equalTo(1);
//        make.width.mas_equalTo([UIScreen mainScreen].bounds.size.width);
//    }];
}

- (void)setMovieInfo:(LXNewMovie *)movieInfo {
    _movieInfo = movieInfo;
    
    UIImage *image = [UIImage imageNamed:movieInfo.posterImageUrl];
    if (image.size.width > PosterImageWidth) {
        CGSize size = CGSizeMake(PosterImageWidth, image.size.height * (PosterImageWidth / image.size.width));
        image = [image reSizeImage:image toSize:size];
    }
    self.posterImageView.image = image;
    self.movieNameLbl.text = movieInfo.movieName;
    NSString  *gradeStr = [NSString stringWithFormat:@"%0.1f分", [movieInfo.grade floatValue]];
    [self.gradeBtn setTitle:gradeStr forState:UIControlStateNormal];
    self.directorNameLbl.text = movieInfo.directorName;
    self.releaseDateLbl.text = movieInfo.releaseDate;
    self.movieNotesLbl.text = movieInfo.movieNotes;
}

// 自绘分割线
- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetStrokeColorWithColor(context, RGBA(255, 255, 255, 0.15).CGColor);
    CGContextStrokeRect(context, CGRectMake(0, rect.size.height - 1, rect.size.width, 1));
}

@end
