//
//  LXCellHeader.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/27.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LXCellHeader : NSObject

@property (nonatomic, copy)NSString *imageUrl;
@property (nonatomic, copy)NSString *titleName;

@end
