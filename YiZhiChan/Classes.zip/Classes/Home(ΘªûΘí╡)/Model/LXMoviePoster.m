//
//  LXMoviePoster.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/29.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXMoviePoster.h"

@implementation LXMoviePoster

@end
