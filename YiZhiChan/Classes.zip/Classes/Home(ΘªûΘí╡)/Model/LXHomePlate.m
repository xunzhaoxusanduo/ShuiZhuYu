//
//  LXHomePlate.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/28.
//  Copyright © 2016年 吴亚举. All rights reserved.
//  首页板块模型

#import "LXHomePlate.h"

@implementation LXHomePlate

+ (instancetype)homePlateWithDictionary:(NSDictionary *)dic {
    return [[self alloc] initWithDictionary:dic];
}

- (instancetype)initWithDictionary:(NSDictionary *)dic {
    if (self = [super init]) {
        self.moduleType = dic[@"moduleType"];
        self.moduleName = dic[@"moduleName"];
        self.imageUrl = dic[@"imageUrl"];
    }
    
    return self;
}

@end
