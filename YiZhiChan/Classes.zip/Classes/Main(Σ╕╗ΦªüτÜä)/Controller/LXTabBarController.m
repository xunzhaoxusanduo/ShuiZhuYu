//
//  LXTabBarController.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/26.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXTabBarController.h"
#import "LXHomeViewController.h"
#import "LXBaseNavigationController.h"
#import "LXWebViewController.h"
#import "RxWebViewNavigationViewController.h"
#import "RxWebViewController.h"
#import "LXMeViewController.h"
#import "LXFriendViewController.h"
#import "LXPlayViewController.h"
#import "LXMovieViewController.h"

@interface LXTabBarController ()

@end

@implementation LXTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupAllChildViewControllers];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"Topbar-bg"] forBarMetrics:UIBarMetricsDefault];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma mark - 私有方法
/**
 *  初始化所有的子控制器
 */
- (void)setupAllChildViewControllers
{
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"shuizhuyu" ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSString *path = nil;
    
//    // 1、首页
//    LXHomeViewController *homeVc = [[LXHomeViewController alloc] init];
//    [self setupChildViewController:homeVc title:@"首页" imageName:@"home_tab_home" selectedImageName:@"home_tab_home"];
//    
//    // 2.电影票
//    path = [bundle pathForResource:@"priceDetail" ofType:@"html" inDirectory:nil];
//    LXMovieViewController* movieVc = [[LXMovieViewController alloc] init];
//    movieVc.urlString = path;
//    [self setupChildViewController:movieVc title:@"电影票" imageName:@"home_tab_movie" selectedImageName:@"home_tab_movie"];
//    
//    // 3.玩吧
//    path = [bundle pathForResource:@"recreationShow" ofType:@"html" inDirectory:@"recreation"];
//    LXPlayViewController* playVc = [[LXPlayViewController alloc] init];
//    playVc.urlString = path;
//    [self setupChildViewController:playVc title:@"玩吧" imageName:@"home_tab_play" selectedImageName:@"home_tab_play"];
//    
//    // 4.朋友圈
//    path = [bundle pathForResource:@"friendCircle" ofType:@"html" inDirectory:@"other"];
//    LXFriendViewController* friendVc = [[LXFriendViewController alloc] init];
//    friendVc.urlString = path;
//    [self setupChildViewController:friendVc title:@"朋友圈" imageName:@"home_tab_friend" selectedImageName:@"home_tab_friend"];
    // 5.我的
    //    path = [bundle pathForResource:@"information" ofType:@"html" inDirectory:@"myData"];
    //    LXMeViewController* meVc = [[LXMeViewController alloc] init];
    //    meVc.urlString = path;
//    [self setupChildViewController:meVc title:@"我的" imageName:@"home_tab_me" selectedImageName:@"home_tab_me"];
    
    // 1、首页
    LXHomeViewController *homeVc = [[LXHomeViewController alloc] init];
    [self setupChildViewController:homeVc title:@"首页" imageName:@"home_tab_home" selectedImageName:@"home_tab_home"];
    
    // 2.电影票
    path = [bundle pathForResource:@"priceDetail" ofType:@"html" inDirectory:nil];
    LXMovieViewController* movieVc = [[LXMovieViewController alloc] initWithUrl:[NSURL fileURLWithPath:path]];
    [self setupChildViewController:movieVc title:@"电影票" imageName:@"home_tab_movie" selectedImageName:@"home_tab_movie"];
    
    // 3.玩吧
    path = [bundle pathForResource:@"recreationShow" ofType:@"html" inDirectory:@"recreation"];
    LXPlayViewController* playVc = [[LXPlayViewController alloc] initWithUrl:[NSURL fileURLWithPath:path]];
    [self setupChildViewController:playVc title:@"玩吧" imageName:@"home_tab_play" selectedImageName:@"home_tab_play"];
    
    // 4.朋友圈
    path = [bundle pathForResource:@"friendCircle" ofType:@"html" inDirectory:@"other"];
    LXFriendViewController* friendVc = [[LXFriendViewController alloc] initWithUrl:[NSURL fileURLWithPath:path]];
    [self setupChildViewController:friendVc title:@"朋友圈" imageName:@"home_tab_friend" selectedImageName:@"home_tab_friend"];
    
    // 5.我的
    path = [bundle pathForResource:@"information" ofType:@"html" inDirectory:@"myData"];
    LXMeViewController* meVc = [[LXMeViewController alloc] initWithUrl:[NSURL fileURLWithPath:path]];
    [self setupChildViewController:meVc title:@"我的" imageName:@"home_tab_me" selectedImageName:@"home_tab_me"];
}

/**
 *  初始化一个子控制器
 *
 *  @param childVc           需要初始化的子控制器
 *  @param title             标题
 *  @param imageName         图标
 *  @param selectedImageName 选中的图标
 */
- (void)setupChildViewController:(UIViewController *)childVc title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    // 1.设置控制器的属性
    childVc.title = title;
    // 设置图标
    childVc.tabBarItem.image = [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    childVc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    
    // 2.包装一个导航控制器
    LXBaseNavigationController *nav = [[LXBaseNavigationController alloc] initWithRootViewController:childVc];
    [self addChildViewController:nav];
}

- (RxWebViewController *)openHtml:(NSString *)name withDirectory:(NSString *)directory{
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"shuizhuyu" ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSString *path = nil;
    
    if (directory) {
        path = [bundle pathForResource:name ofType:@"html" inDirectory:directory];
        NSLog(@"%@", path);
    }else {
        path = [bundle pathForResource:name ofType:@"html"];
        NSLog(@"%@", path);
    }
    
    RxWebViewController* webViewController = [[RxWebViewController alloc] initWithUrl:[NSURL URLWithString:path]];
    webViewController.progressViewColor = [UIColor clearColor];
    return webViewController;
}

@end