﻿$(document).on('pagebeforeshow', function ()
//$(function()
{
    //数据初始化
    init();     
});
function init()
{
    var url = location.search;
    var val = url.split("=")[1];
    if (val == "NaN" || val == 0)
    {
        return false;
    }
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/SubTitleShow/PictureById',
        data: { mid:val },
        type: 'get',
        dataType: 'json',
        async:false,
        success: function (data)
        {
            var html = data.data;
            if (data.state == 2)
            {
                alert(data.msg); return false;
            }
             
            $("#touchMove").append(html);
            var firstImg = $("li:eq(0)>img").attr("src");
            $("#imgBg").attr("src", firstImg);
        }, error: function (a, c, v)
        {
            alert("错误");
        }
    });
}