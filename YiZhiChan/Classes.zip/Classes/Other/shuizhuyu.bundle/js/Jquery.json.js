﻿
/*
author:sun hongtao
date:2012-01-09
summary:从对象转成json格式的字符串
        function 不做转换,数组属性不做转换
example:
var data=[{a:'1'}];
data.bb=1;
var str=$.toJSON(data);
var data1=$.toJSON(str);
*/
(function ($) {
    $.extend({
        toJSON: function (obj) {
            if (obj == null) {
                return null;
            }
            var type = typeof (obj);
            if (type == 'number' || type == 'boolean') {
                return obj;
            }

            else if (type == 'string') {
                obj = obj.replace(/\\/gmi, '\\\\');
                obj = obj.replace(/"/gmi, '\\"');
                obj = obj.replace(/\r\n/g, '\\r\\n')
                         .replace(/\n/g, '\\r\\n')
                         .replace(/\r/g, '\\r\\n')
                         .replace(/\f/g, '\\f')
                         .replace(/\t/g, '\\t');
                return '"' + obj + '"';
            } else if ($.isArray(obj)) {
                var data = [];
                for (var k = 0; k < obj.length; k++) {
                    var value = $.toJSON(obj[k]);
                    if (value == null) {
                        value = 'null';
                    }
                    data.push(value);
                }
                var str = '[' + data.join(",") + ']';
                return str;
            } else if (type == 'object') {
                var data = [];
                for (var k in obj) {
                    var objk = obj[k];
                    if (typeof (objk) == 'function') {
                        continue;
                    }
                    var value = $.toJSON(objk);

                    var jsonstr = '"' + k + '":' + value;
                    data.push(jsonstr);
                }
                var str = '{' + data.join(",") + '}';
                return str;
            }
            else if (type == 'function') {

                var str = obj.toString();
                str = '"' + str.replace(/"/gmi, '\\"') + '"';
                return str;
            }
            else {
                return '"undefined"';
            }
        }
    });
})(jQuery);

/*
author:sun hongtao
date:2012-10-26
summary:对数据做克隆
example:
var data=[{a:'1'}];
data.bb=1;
var str=$.toJSON(data);
var data1=$.toJSON(str);
*/
(function ($) {
    $.extend({
        cloneData: function (obj) {
            if (obj == null) {
                return null;
            }

            var type = typeof (obj);
            if (type == 'number' || type == 'boolean') {
                return obj;
            } else if (type == 'string') {

                return obj;
            } else if ($.isArray(obj)) {
                var data = [];
                for (var k = 0; k < obj.length; k++) {
                    var value = $.cloneData(obj[k]);
                    data.push(value);
                }
                return data;
            } else if (type == 'object') {
                var data = {};
                for (var k in obj) {
                    var objk = obj[k];
                    if (typeof (objk) == 'function') {
                        continue;
                    }
                    var value = $.cloneData(objk);
                    data[k] = value;
                }
                return data;
            }
            else if (type == 'function') {

                var str = obj.toString();
                str = '"' + str.replace(/"/gmi, '\\"') + '"';
                return str;
            }
            else {
                return '"undefined"';
            }
        }
    });
})(jQuery);

/*
表单元素序列化成对象
$.serializeObj('form')
$('form').serializeObj();
*/
(function ($) {
    $.extend({
        toObj: function (sel) {
            return $(sel).toObj();
        }
    });
    $.fn.extend({
        toObj: function () {
            var arr = this.serializeArray();
            var data = [];
            for (i in arr) {
                var datai = arr[i];
                var val = datai.value;
                if (val) {
                    val=val.replace(/[\u0000-\u0009\u000b\u000c\u000e-\u001F]/g,'');
                    val = val.replace(/\\/gmi, '\\\\');
                    val = val.replace(/"/gmi, '\\"');
                    val = val.replace(/\r\n/g, '\\r\\n')
                             .replace(/\n/g, '\\r\\n')
                             .replace(/\r/g, '\\r\\n')
                             .replace(/\f/g, '\\f')
                             .replace(/\t/g, '\\t');
                }
                var d = '"' + datai.name + '":"' + val + '"';
                data.push(d);
            }
            var jsonstr = '{' + data.join(',') + '}'
            return $.parseJSON(jsonstr);
        }
    });
})(jQuery);
