//$(document).on('pageinit', function ()
$(function ()
{
   selectClick();
   touchMove();
   touchMove1();
   strings();
});
function strings(){
    var oSpan = $('.actor_text p span'),
        oStrong = $('.actor_text p strong'),
        oI = $('.arrow_d i'),
        onOff = true,
        str = oSpan.text(),
        str_c = str.substring(0,60);
    oSpan.text(str_c);
    oI.click(function(){
        if(onOff){
            oSpan.text(str);
            oStrong.text('。');
            //oI.text('&#xe60f;');
            onOff = false;
        }else{
            oSpan.text(str_c);
            oStrong.text(' ...');
            //oI.text('&#xe60f;');
            onOff = true;
        }
    });
}
function selectClick(){
    var oA = $('.actor .comment a');
    oA.click(function(){
        oA.removeClass('active');
        $(this).addClass('active');
    });
}
function touchMove(){
    var oUl = $('.actor_info ul'),
        oLi = $('.actor_info ul li'),
        touchMove = $('#touchMove').width(),
        i = oLi.length;
    //设置宽度
    oLi.css('width',touchMove/3);
    oUl.css('width',touchMove*i/3);
}

function touchMove1(){
    var oDd = $('.madeCharacter dd'),
        oA  = $('.addPic a');
    oA.click(function(){
        oDd.eq(0).clone().appendTo($('.madeCharacter'));
        var len = $('.madeCharacter dd').length;
        for(var i=0; i<len; i++){
            move($('.madeCharacter dd').eq(i));
        }
    });
    //加载时就掉用move
    move(oDd.eq(0));
    function move(obj){
        var oUl = obj.find('.subtitle_pic ul'),
            oLi = obj.find('.subtitle_pic ul li'),
            oImg = obj.find('.subtitle_big img'),
            touchMove = obj.find('.subtitle_pic').width(),
            i = oLi.length;
        //设置宽度
        oLi.css('width',touchMove/3);
        oUl.css('width',touchMove*i/3);
        oLi.click(function(){
            oImg.attr('src',$(this).find('img').attr('src'));
        })
    }
}






























