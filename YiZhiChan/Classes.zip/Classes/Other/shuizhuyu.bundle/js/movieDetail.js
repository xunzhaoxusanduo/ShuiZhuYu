﻿ 
 
$(document).on('pageinit', function () {
    var MovieInfoId =API.getSearchParam("MovieInfoId"); 
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/Movie/MovieInfo?MovieInfoId=' + MovieInfoId,
        type: 'get',
        dataType: 'json',
        success: function (data) {
            if (data.state == 1) {
                var movie = data.data.movie;
                var poster = data.data.poster;
                var trailer = data.data.trailer;
                var actor = data.data.actor;
                var msg = data.data.movieMsg;
                var comment = data.data.movieComment;
                $('#MovieName').html(movie.movieName);
                $('#Rating').html(movie.rating);
                $('#Cover').attr('src', movie.cover);
                var time = movie.movieTime;
                $('#Time').html(parseInt(time / 60) + '小时' + time % 60 + '分钟/' + movie.language);
                $('#remark').html(movie.remarks);
                var movietype = movie.movieType.split('/');
                $.each(movietype, function (i, v) {
                    $('#MovieType').append('<a href="javascript:;"><span>'+v+'</span></a>');
                })
                $(actor, function (i, v) {
                    $('#Actor').append('<li data-actorid="'+v.actorId+'"><span><img src="' + v.headPortrait + '" alt="明星照片"/></span><P>' + v.fullName + '</P></li>');
                })
                if(movie.details.length>200){
                    $('#Details').html('简介： ' + movie.details.substr(0,198)+'......');
                    $('.arrow_d').show();
                }else{
                    $('#Details').html('简介： ' + movie.details);
                    $('.arrow_d').hide();
                }
                $(document).on('vclick','#more',function(){
                    $('#Details').html('简介： ' + movie.details);
                })
                $('#TrailerCount').html(trailer.length);
                $('#PosterCount').html(poster.length);
                if (trailer.length > 0) {
                    $('#Video').attr('src', trailer[0].videoUrl);
                    $('#Trailer').attr('src', trailer[0].videoUrl);
                }
                if (poster.length > 0) {
                    $('#Poster').attr('src',poster[0].imageUrl);
                }
                var msgHtml = [];
                $.each(msg, function (i, v) {
                    msgHtml.push('<li class="clear pad4"><a class="signalList_l clear">');
                    msgHtml.push('<div class="fl"><img src="../img/signal.jpg" alt="影院图片"/></div>');
                    msgHtml.push('<div class="signalList_con"><h2>' + v.title + '</h2>');
                    msgHtml.push('<p>' + (v.content.length > 30 ? v.content.substr(0, 29) + '...' : v.content) + '</p></div></a>');
                    var timeinfo = v.addTime.split(' ');
                    var year = timeinfo[0].split('-')[0];
                    var month = parseInt(timeinfo[0].split('-')[1]) - 1;
                    var day = parseInt(timeinfo[0].split('-')[2]);
                    var hour = parseInt(timeinfo[1].split(':')[0]);
                    var minute = parseInt(timeinfo[1].split(':')[1]);
                    var Second = parseInt(timeinfo[1].split(':')[2]);
                    var timePass = (new Date().getTime() - new Date(year, month, day, hour, minute, Second).getTime()) / 1000;
                    var time ;
                    if (timePass > 60*60*24*365) {
                        time = parseInt(timePass/(60*60*24*365))+'年前';
                    } else if (timePass > 60*60*24*30) {
                        time = parseInt(timePass / (60 * 60 * 24 * 30)) + '月前';
                    } else if (timePass > 60 * 60 * 24) {
                        time = parseInt(timePass / (60 * 60 * 24)) + '天前';
                    } else if (timePass > 60 * 60) {
                        time = parseInt(timePass / (60 * 60)) + '小时前';
                    }else if(timePass > 60) {
                        time = parseInt(timePass / 60) + '分钟前';
                    }else{
                        time=timePass+'秒前';
                    }
                    msgHtml.push('<div class="recreation_r"><div class="clear comment"><span class="fl">'+time+'</span>');
                    msgHtml.push('<span class="fr"><a href="javascript:;"><i class="comment_bg"></i><em>' + v.praiseCount + '</em></a>');
                    msgHtml.push('<a href="javascript:;"><i class="iconfont icon">&#xe621;</i><em>' + v.commentCount + '</em></a></span></div></div></li>');
                })
                $('.signalList').html(msgHtml.join(''));
                $('#CommentCount').html('(' + comment.movieCommentCount + ')');
                var commentHtml = [];
                $.each(comment.movieCommentInfo, function (i, v) {
                    commentHtml.push('<li class="pad4 clear"><div class="subtitleList_t clear"><div class="fl">');
                    commentHtml.push('<span data-toggle="modal" data-target="#myModal"><img src="' + v.headPortrait + '" alt="头像"/></span>');
                    commentHtml.push('<strong class="col">' + v.nickName + '</strong><img src="../img/grade_' + v.level + '.png" class="grade" alt=""/></div>');
                    commentHtml.push('<div class="fr"><b></b></div></div>');
                    commentHtml.push('<p>' + v.comment + '</p>');
                    var timeinfo = v.addTime.split(' ');
                    var year = timeinfo[0].split('-')[0];
                    var month = parseInt(timeinfo[0].split('-')[1])-1;
                    var day = parseInt(timeinfo[0].split('-')[2]);
                    var hour = parseInt(timeinfo[1].split(':')[0]);
                    var minute = parseInt(timeinfo[1].split(':')[1]);
                    var Second = parseInt(timeinfo[1].split(':')[2]);
                    var timePass = (new Date().getTime() - new Date(year, month, day, hour, minute,Second).getTime()) / 1000;
                    
                    var time;
                    if (timePass > 60 * 60 * 24 * 365) {
                        time = parseInt(timePass / (60 * 60 * 24 * 365)) + '年前';
                    } else if (timePass > 60 * 60 * 24 * 30) {
                        time = parseInt(timePass / (60 * 60 * 24 * 30)) + '月前';
                    } else if (timePass > 60 * 60 * 24) {
                        time = parseInt(timePass / (60 * 60 * 24)) + '天前';
                    } else if (timePass > 60 * 60) {
                        time = parseInt(timePass / (60 * 60)) + '小时前';
                    } else if (timePass > 60) {
                        time = parseInt(timePass / 60) + '分钟前';
                    } else {
                        time = timePass + '秒前';
                    }
                    commentHtml.push('<div class="recreation_r"><div class="clear comment"><span class="fl">' + time + '</span>');
                    commentHtml.push('<span class="fr"><a href="javascript:;"><i class="comment_bg"></i><em>' + v.praiseCount + '</em></a>'); 
                    commentHtml.push('</span></div></div></li>');
                })
                $('.allComment').html(commentHtml.join(''));
            }
        },
        error: function (xhr, textStatus, err) {
            alert(err);
        }
    })
})
