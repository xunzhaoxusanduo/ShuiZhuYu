﻿$(document).on('pageinit', function ()
//$(function ()
{
    $("#pl").empty();
    var i = 0; //设置评论当前页数 
    var mIndex = 0;//制作字幕秀
    var url = location.search;
    var val = url.split("=")[1];
    //数据初始化
    init(i, val);

    //$("#createShow").on("vclick",  
     $("#createShow").on("vclick",
     function()
     {
         Show(mIndex);
     });
    //评论
     $("#btnComment").on("vclick", function ()
     {
         //$.ajax({
         //    url: 'http://devftp.lansum.cn/fishapi/api/SubtitleDetail/CommentAdd',
         //    data: { SubTitleShowId: val, Content: $("#comment").text() },
         //    type: 'post',
         //    dataType: 'json',
         //    success: function (data)
         //    {
         //        if (data.state != 1)
         //        {
         //            alert(data.msg);
         //        }
         //        else
         //        {
         //            init(0, val);
         //        }

         //    }, error: function (a, c, v)
         //    {
         //        alert("错误");
         //    }
         //});
     });
    ScrollLoadData(i,mIndex,   $(window).height(), val);
    infoByImg();
   
    
})


function init(index,val)
{
    var id = parseInt(val);
    if ( id=="NaN" ||id==0)
    {
        return false;
    }
    $(".play").empty();
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/SubtitleDetail/SubTitleDetailShowList',
        data: { pageIndex: index, pageSize: 5, SubTitleShowId: id },
        type: 'get',
        dataType: 'json',
        cache:false,
        success: function (data)
        {
            var json = data.data;
            if (data.state == 2)
            {
                alert(data.msg); return false;
            }
            $("#pl").append(json.html)
            for (var i = 0; i < json.imgs.length; i++)
            {
                var url = json.imgs[i];
                //var i = $("img").attr("src", json.Imgs[i]);
                var img = $("<img/>",
                     {
                         src: url
                     });
                var divText = $("<div/>",
                {
                    class: 'text',
                    text: json.content[i]
                   
                    });
                //<div class="text">你好！我是金刚，你是泰山吗？</div>
                var s = $("<li/>").append(img).append(divText);
                $("#play").append(s);
            }

        }, error: function (a, c, v)
        {
            alert("错误");
        }
    });
}



//制作字幕秀
function Show(index)
{
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/SubtitleDetail/MovieImgList',
        data: { pageIndex: index },
        type: 'get',
        dataType: 'json',
        success: function (data)
        {
            if (data.state != 1)
            {
                alert(data.msg);
            }
            $("#subtitleDetails").append(data.data);

        }, error: function (a, c, v)
        {
            alert("错误");
        }
    });

}


function ScrollLoadData(plIndex,mIndex, winH,id)
{
    $(document).on("scrollstop", function ()
    {
        //////alert("停止滚动!");
        var pageH = $(document.body).height();
        var scrollT = $(window).scrollTop(); //滚动条top 
        var aa = (pageH - winH - scrollT) / winH;
        if (aa < 0.02)
        {
            if ($("#comment1").hasClass("active"))//评论
            {
                init(++plIndex, id);
            }
            else //制作字幕秀 #subtitle
            {
                Show(++mIndex);
            }
        }
    });
}
