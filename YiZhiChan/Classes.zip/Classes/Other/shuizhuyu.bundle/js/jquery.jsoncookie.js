/** 
 * JSON Cookie - jquery.jsoncookie.js
 *
 * Sets and retreives native JavaScript objects as cookies.
 * Depends on the object serialization framework provided by JSON2.
 *
 * Dependencies: jQuery, jQuery Cookie, JSON2
 * 
 * @project JSON Cookie
 * @author Randall Morey
 * @version 0.9
 */
(function ($) {
    $.extend({
        toJSON: function (obj) {
            if (obj == null) {
                return null;
            }
            var type = typeof (obj);
            if (type == 'number' || type == 'boolean') {
                return obj;
            }

            else if (type == 'string') {
                obj = obj.replace(/\\/gmi, '\\\\');
                obj = obj.replace(/"/gmi, '\\"');
                obj = obj.replace(/\r\n/g, '\\r\\n')
                         .replace(/\n/g, '\\r\\n')
                         .replace(/\r/g, '\\r\\n');
                return '"' + obj + '"';
            } else if ($.isArray(obj)) {
                var data = [];
                for (var k = 0; k < obj.length; k++) {
                    var value = $.toJSON(obj[k]);
                    if (value == null) {
                        value = 'null';
                    }
                    data.push(value);
                }
                var str = '[' + data.join(",") + ']';
                return str;
            } else if (type == 'object') {
                var data = [];
                for (var k in obj) {
                    var objk = obj[k];
                    if (typeof (objk) == 'function') {
                        continue;
                    }
                    var value = $.toJSON(objk);

                    var jsonstr = '"' + k + '":' + value;
                    data.push(jsonstr);
                }
                var str = '{' + data.join(",") + '}';
                return str;
            }
            else if (type == 'function') {

                var str = obj.toString();
                str = '"' + str.replace(/"/gmi, '\\"') + '"';
                return str;
            }
            else {
                return '"undefined"';
            }
        }
    });
})(jQuery);

(function ($) {
	var isObject = function (x) {
		return (typeof x === 'object') && !(x instanceof Array) && (x !== null);
	};
	
	$.extend({
		getJSONCookie: function (cookieName) {
			var cookieData = $.cookie(cookieName);
			return cookieData ? $.parseJSON(cookieData) : null;
		},
		setJSONCookie: function (cookieName, data, options) {
			var cookieData = '';
			
			options = $.extend({
				
				path: '/'
			}, options);
			if (!isObject(data)) {	// data must be a true object to be serialized
				throw new Error('JSONCookie data must be an object');
			}
			
			cookieData = $.toJSON(data);
			
			return $.cookie(cookieName, cookieData, options);
		},
		removeJSONCookie: function (cookieName,options) {
			return $.cookie(cookieName, null,options);
		},
		JSONCookie: function (cookieName, data, options) {
			if (data) {
				$.setJSONCookie(cookieName, data, options);
			}
			return $.getJSONCookie(cookieName);
		}
	});
})(jQuery);
