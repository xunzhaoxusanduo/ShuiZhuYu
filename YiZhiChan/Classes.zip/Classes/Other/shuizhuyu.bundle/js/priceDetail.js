﻿var MovieInfoId = 0;

$(document).on('pageinit', function () {
    var mid = [359, 354];

    MovieInfoId = mid[parseInt(Math.random() * 2)];
    //MovieInfoId = API.getSearchParam("MovieInfoId");
    //TODO 根据手机定位获取经纬度，默认加载附近的电影院
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/Movie/ComparePrice',
        type: 'get',
        data:{MovieInfoId:MovieInfoId,longitude:111,latitude:222},
        dataType: 'json',
        success: function (data) {
            if (data.state == 1) {
                var movie = data.data.movie;
                $('#Cover').attr('src', movie.cover);
                var tickets = data.data.tickets;
                var html = []; 
                $.each(tickets, function (index, value) {
                    //每一个电影院
                    html.push('<div class="bg price"><h2 class="comment_tit col clear">');
                    //TODO显示多少米距离
                    html.push('<span class="fl">' + value[0][0].cinemaName + '<strong>' + value[0][0].address + '</strong></span>');
                    html.push('<a href="###" class="fr"><i class="iconfont icon">&#xe642;</i></a></h2>');
                    html.push('<ul class="priceList"><li class="clear"><a href="javascript:;">场次</a>');
                    html.push('<a href="javascript:;"><img src="img/maoyan.png" alt="猫眼"/></a>');
                    html.push('<a href="javascript:;"><img src="img/gewara.png" alt="格瓦拉"/></a>');
                    html.push('<a href="javascript:;"><img src="img/weChat.png" alt="微信"/></a>');
                    html.push('<a href="javascript:;"><img src="img/taobao.png" alt="淘宝"/></a></li>');
                    $.each(value, function (i, v) {
                        //每一个场次
                        var timeinfo = v[0].showTime.split(' ');
                        var year = timeinfo[0].split('-')[0];
                        var month = parseInt(timeinfo[0].split('-')[1]) - 1;
                        var day = parseInt(timeinfo[0].split('-')[2]);
                        var hour = parseInt(timeinfo[1].split(':')[0]);
                        var minute = parseInt(timeinfo[1].split(':')[1]);
                        var Second = parseInt(timeinfo[1].split(':')[2]);
                        var showtime = new Date(year,month,day,hour,minute,Second);
                        var month=showtime.getMonth() + 1;
                        var date=showtime.getDate();
                        var minutes=showtime.getMinutes()==0?'00':showtime.getMinutes();
                        var Hours=showtime.getHours()==0?'00':showtime.getHours();
                        html.push('<li class="clear"><a href="javascript:;">' + month + '月' + date + '号 ' + Hours + ':' + minutes + '</a>');
                        var prices = { 1: null, 2: null, 3: null, 4: null};
                        
                        $.each(v, function (m, n) {
                            //每个票务平台
                            prices[n.platformId] = n; 
                        })
                        for (var n = 1; n < 5; n++) {
                            if (prices[n] == null) {
                                html.push('<a href="#">/</a>');
                            }
                            else
                            {
                                var url = '';
                                switch (n)
                                {
                                    case 1:
                                        url = 'http://m.maoyan.com/?tmp=showtime&cinemaid=' + prices[n].ticketPlatformCinemaId + '&movieid=' + prices[n].ticketPlatformMovieId;
                                        break;
                                    case 2:
                                        url = 'http://m.gewara.com/movie/m/choiceMovieSim.xhtml?cid=' + prices[n].ticketPlatformCinemaId + '&mid=' + prices[n].ticketPlatformMovieId + '&openDate=2016-05-1'
                                        break;
                                    case 3:
                                        url = 'http://m.wepiao.com/#/cinemas/' + prices[n].ticketPlatformCinemaId + '?movieId=' + prices[n].ticketPlatformMovieId;
                                        break;
                                    case 4:
                                        url = 'http://h5.m.taobao.com/app/movie/pages/index/show-list.html?showid=' + prices[n].ticketPlatformMovieId + '&cinemaid=' + prices[n].ticketPlatformCinemaId;
                                        break;
                                }
                                html.push('<a   href="'+url+'">¥' + prices[n].price + '</a>');
                            } 
                        }
                       
                        html.push('</li>');
                    })
                    html.push('</ul></div>');
                })
                $('.content1').append(html.join(''));
            }
        },
        error:function(){
        
        }
    })
})