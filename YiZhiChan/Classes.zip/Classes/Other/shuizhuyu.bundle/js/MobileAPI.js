﻿var API = {};

API.contentId = '#content';

API.IsMobileShell = function () {

    if (API.bridge && API.bridge.send || window.android && window.android.camraZbar) {
        return true;
    }
    else {
        return false;
    }
};




//iphone 连接器
API.connectWebViewJavascriptBridge = function (callback) {
    if (window.WebViewJavascriptBridge) {
        callback(WebViewJavascriptBridge)
    } else {
        document.addEventListener('WebViewJavascriptBridgeReady', function () {
            callback(WebViewJavascriptBridge)
        }, false)
    }
};

//iphone 连接器
API.funRegIPhoneHandler = function (bridge) {
    var uniqueId = 1
    API.bridge = bridge;
    bridge.init(function (message, responseCallback) {
        //log('JS got a message', message)
        var data = { 'Javascript Responds': 'Wee!' }
        //log('JS responding with', data)
        responseCallback(data)
    });//end init

    bridge.registerHandler('setMobileCookieTextIphone', function (data, responseCallback) {
        $('#content').append('setMobileCookieTextIphone回调成功,开始解析数据');
        setMobileCookieTextIPhoneCallback(data.cookieName, data.callbackName, data.result);
        var responseData = { info: '获取经纬度成功' };
        responseCallback(responseData)
    });

};

function setMobileCookieTextIPhoneCallback(cookiename, callbackFun, data) {
    //alert(cookiename)
    $('#content').append('获取到cookie:' + cookiename + ',回调函数名' + callbackFun + ',data:' + data);
    $('#content').append('userid:' + data.userid);

    eval(callbackFun + '(' + $.toJSON(data) + ',"' + cookiename + '")');
}

function setMobileCookieText(cookiename, callbackFun, data) {
    //alert(data)
    $('#content').append('获取到cookie:' + cookiename + ',回调函数名' + callbackFun + ',data:' + data);
    $('#content').append('userid:' + data.userid);

    eval(callbackFun + '(' + (data) + ',"' + cookiename + '")');
}

//<--客户端相机扫描完回传数据给页面-->
function setCamraZbar(content) {
    //显示内容或者跳转页面操作
    API.funScanZbarResult(content);

}

//<--客户端定位成功回传给页面经纬度-->
function setLocation(content) {
    //显示内容或者跳转页面操作
    API.funSetLocation(content);
}

var isIphone = navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;;
if (isIphone) {
    /******************/
    API.connectWebViewJavascriptBridge(API.funRegIPhoneHandler);
    /******************/

    API.OpenNewWindow = function (url) {


        API.bridge.send({ type: 'OpenNewWindow', info: url });
    };

    //拨打电话
    API.funCall = function (e) {
        //alert('Iphone funcall 1')
        if (API.bridge && API.bridge.send) {
            //  alert('Iphone funcall 2')
            var tel = $(this).attr('href').match(/\d+/)[0];

            e.preventDefault();
            API.bridge.send({ type: 'call', info: tel });
        }
    }

    //二维码扫描
    API.funScanZbar = function (e) {

        if (API.bridge && API.bridge.send) {
            e.preventDefault();
            API.bridge.send({ type: 'camraZbar' }, function (responseData) {
                API.funScanZbarResult(responseData);
            });
        } else {
            $.mobile.showPageLoadingMsg("e", '请下载客户端', true); FindPwdJS.TimingCloseMsg("5000");
        }



    }

    //设置当前手机位置
    API.funGetLocation = function (e) {
        e.preventDefault();
        //$(API.contentId).html('触发获取位置');
        API.bridge.send({ type: 'mobileGetLocation' }, function (responseData) {
            API.funSetLocation(responseData);
        });
        //$(API.contentId).html('获取位置:' + position);
        return false;
    }

    //打开地图
    API.funOpenMap = function (name, lat, lng, address, tel) {
        var obj = [{
            name: name,
            lat: lat,
            lng: lng,
            address: address,
            tel: tel
        }];

        //$(API.contentId).html('打开地图');
        var json = $.toJSON(obj);
        API.bridge.send({ type: 'locationList', info: json });
        return false;
    };



    API.ReadCookie = function (cookieName, callbackName) {

        //$('#content').append('开始读取Iphone cookieB<br>');
        API.bridge.send({ type: 'getMobileCookie', cookieName: cookieName, callbackName: callbackName });

        //$('#content').append('结束读取cookieB<br>');
    };

    API.WriteCookie = function (cookieName, data) {
        if (API.bridge) {
            //$('#content').append('开始写入Iphone cookieA<br>');
            API.bridge.send({ type: 'setMobileCookie', cookieName: cookieName, info: data });
            //$('#content').append('写入完成A<br>');
        }


    };

    API.showGuide = function () {
        API.bridge.send({ type: 'showGuide' });
    }

} else {
    API.OpenNewWindow = function (url) {
        //alert('mobileCall' + window.android.mobileCall)
        //alert('OpenNewWindow' + window.android.OpenNewWindow)
        window.android.OpenNewWindow(url);
    };

    //拨打电话
    API.funCall = function (e) {
        //alert('android funcall 1')
        //alert('android:' + window.android)
        //alert('android mobileCall:' + window.android.mobileCall)
        if (window.android) {
            //alert('android funcall 2')
            var tel = $(this).attr('href').match(/\d+/)[0];
            e.preventDefault();
            window.android.mobileCall(tel);
        }
    }

    //二维码扫描
    API.funScanZbar = function (e) {
        if (window.android && window.android.camraZbar) {
            e.preventDefault();
            window.android.camraZbar();
        } else {
            $.mobile.showPageLoadingMsg("e", '请下载客户端', true); FindPwdJS.TimingCloseMsg("5000");
        }
    }

    //设置当前手机位置
    API.funGetLocation = function (e) {
        e.preventDefault();
        //$(API.contentId).html('触发获取位置');
        var position = window.android.mobileGetLocation();
        //$(API.contentId).html('获取位置:' + position);
        return false;
    }

    //打开地图
    API.funOpenMap = function (name, lat, lng, address, tel) {
        var obj = [{
            name: name,
            lat: lat,
            lng: lng,
            address: address,
            tel: tel
        }];

        //$(API.contentId).html('打开地图');
        var json = $.toJSON(obj);
        window.android.locationList(json);
        return false;
    };

    API.ReadCookie = function (cookieName, callbackName) {
        if (window.android) {
            // alert('read cookie A');
            //$('#content').append('开始读取Iphone cookieB<br>');
            window.android.getMobileCookie(cookieName, callbackName);

            //$('#content').append('结束读取cookieB<br>');
        }  
    };
    API.ReadCookie = function (cookieName) {
        return $.JSONCookie(cookieName);
    }
    API.WriteCookie = function (cookieName, data) {
        if (window.android) {
            //$('#content').append('开始写入Iphone cookieA<br>');
            window.android.setMobileCookie(cookieName, $.toJSON(data));
            //$('#content').append('写入完成A<br>');
        } else {
            $.JSONCookie(cookieName,data);
        }


    };

    API.showGuide = function () {
        window.android.showGuide();
    }

}


//处理扫描结果回调
API.funScanZbarResult = function (content) {

}

//获取手机位置回调
API.funSetLocation = function (content) {
    //$(API.contentId).html('获取到的位置:' + content);
}

API.getSearchParam=function(key, dv, isRaw) {
    var searchstr = window.location.search || '';
    var regex = new RegExp('\\b' + key + '=([^&=]+)', 'mi');
    var match = searchstr.match(regex);
    if (match) {
        if (isRaw) {
            return match[1];
        } else {
            try {
                return window.decodeURIComponent(match[1]);
            } catch (e) {
                return '';
            }

        }

    } else {
        return dv || '';
    }

}
$.mobile.ajaxEnabled = false;