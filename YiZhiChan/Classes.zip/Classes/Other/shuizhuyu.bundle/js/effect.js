$(function(){
    wrap_con();
    nav();
    option();
    slider();
    indexFocus();
});
function indexFocus(){
    var banner = $('.focus'),
        slider = $('.focus ul'),
        oA = $('.focus ul li'),
        oP = $('.focus_bg .text .fl p'),
        widths = banner.width();
    oA.eq(0).clone().appendTo(slider);
    var len = $('.focus ul li').length,
        timer = setInterval(auto, 4000),
        m = 0;
    for(var i = 0; i < len-1; i++){
        $('<span></span>').appendTo($('.focus_bg .text .fr'));
    }
    var num = $('.focus_bg .text .fr span');
    num.eq(0).addClass('cur');

    //????slider????
    slider.css('width',widths * len);
    $('.focus ul li').css('width',widths);
    function auto() {
        m++;
        if (m == len) {
            slider.css('marginLeft', 0);
            m = 1;
        }
        showSlider(m);
    }

    function showSlider(n) {
        var lefts = n * widths;
        slider.stop(true, false).animate({'marginLeft': -lefts}, 600);
        num.removeClass('cur');
        oP.removeClass('cur');
        if (n == len - 1) {
            n = 0;
        }
        num.eq(n).addClass('cur');
        oP.eq(n).addClass('cur');
    }

    slider.hover(function () {
        clearInterval(timer);
    }, function () {
        timer = setInterval(auto, 4000);
    });

    num.hover(function () {
        clearInterval(timer);
    }, function () {
        timer = setInterval(auto, 4000);
    });
    num.click(function () {
        var j = $(this).index();
        if( m== len-1){
            slider.css('marginLeft', 0);
        }
        m = j;
        showSlider(j);
    });
}
function slider(){
    var slider = $('.slider ul'),
        oA = $('.slider ul li'),
        widths = oA.eq(0).width();
    oA.eq(0).clone().appendTo(slider);
    var len = $('.slider ul li').length,
         prev = $('.sliderCon .prev'),
         next = $('.sliderCon .next'),
         timer = setInterval(auto, 4000),
         m = 0,
         onOff = true;

    //����slider�Ŀ���
    slider.css('width',widths * len);

    function auto() {
        m++;
        if (m == len) {
            slider.css('marginLeft', 0);
            m = 1;
        }
        showSlider(m);
    }

    function showSlider(n) {
        var nowLeft = -n * widths;
        slider.stop(true, false).animate({'marginLeft': nowLeft},500, function () {
            onOff = true;
        });
    }

    slider.hover(function () {
        clearInterval(timer);
    }, function () {
        timer = setInterval(auto, 4000);
    });

    prev.hover(function () {
        clearInterval(timer);
    }, function () {
        timer = setInterval(auto, 4000);
    });

    next.hover(function () {
        clearInterval(timer);
    }, function () {
        timer = setInterval(auto, 4000);
    });

    prev.click(function () {
        if (onOff) {
            onOff = false;
            m--;
            if (m == -1) {
                slider.css('marginLeft', -widths * (len - 1));
                m = len - 2;
            }
            showSlider(m);
        }
    });

    next.click(function () {
        if (onOff) {
            onOff = false;
            m++;
            if (m == len) {
                slider.css('marginLeft', 0);
                m = 1;
            }
            showSlider(m);
        }
    });
}
function option(){
    var option = $('.option span');
    option.click(function(){
        option.removeClass('cur');
        $(this).addClass('cur');
    });
}
function nav(){
    var oLi = $('.nav li'),
        n = 0;
    for(var i=0; i< oLi.length; i++){
        if(oLi.eq(i).className == 'cur'){
            n = i;
        }
    }
    oLi.hover(function(){
        oLi.removeClass('cur');
        $(this).addClass('cur');
        $(this).children('div').stop(true,false).animate({'height':45},300);
    },function(){
        $(this).children('div').stop(true,false).animate({'height':0},300);
        $(this).removeClass('cur');
        oLi.eq(n).addClass('cur');
    });
}
function wrap_con(){
    var oLi = $('.wrap_con_l ul li'),
        oDiv = $('.wrap_con_r > div');
    oLi.click(function(){
        var i = oLi.index($(this));
        oLi.removeClass('cur');
        $(this).addClass('cur');
        oDiv.eq(i).siblings().hide();
        oDiv.eq(i).fadeIn(500);
    });
}