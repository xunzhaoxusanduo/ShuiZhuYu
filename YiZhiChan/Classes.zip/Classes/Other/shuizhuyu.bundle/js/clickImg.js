﻿//点击头像获取信息
function infoByImg()
{
    $(document).on("click", "img[data-id]",
        function ()
        {
            var id = $(this).attr("data-id")
            if (id == null || id == undefined || id < 1)
            {
                return false;
            }
            $.ajax({
                url: 'http://devftp.lansum.cn/fishapi/api/SubTitleShow/UserFriendInfo',
                data: { id: id },
                type: 'get',
                dataType: 'json',
                success: function (data)
                {
                    var json = data.data;
                    if (data.State == -1)
                    {
                        alert(data.msg);
                        return false;
                    }
                    //alert(json);

                    // $("#showUserInfo").html($(json));
                    //$("#userImg").attr("scr", "'"+json.UserInfo.UserImg+"'");
                    //$("#userName").text(json.UserInfo.UserName);
                    //$("#sex").text(json.UserInfo.Sex);
                    //$("#userLeve").attr("scr", "../img/grade_" + json.UserInfo.Level + ".png");
                    //$("#fs").text(json.FsCount);
                    //$("#gz").text(json.GzCount);
                    //$("#yp").text(json.YpCount);

                    $(".modal-title").empty().append(json.header);
                    $(".modal-body").empty().append(json.content);
                    $(".modal-footer").empty().append(json.foot);

                }, error: function (a, c, v)
                {
                    alert("错误");
                }
            });

        });
}
/// i:index  init:方法 winH:搞
function ScrollLoadData(i, init, winH)
{
    $(document).on("scrollstop", function ()
    {
        //alert("停止滚动!");
        var pageH = $(document.body).height();
        var scrollT = $(window).scrollTop(); //滚动条top 
        var aa = (pageH - winH - scrollT) / winH;
        if (aa < 0.02)
        {
            init(++i);
        }
    });
}