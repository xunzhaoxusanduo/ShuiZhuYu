﻿$(document).on('pageinit', function ()
//$(function()
{
    var subtitleIndex = 0; //字幕
    var posterIndex = 0;//海报索引
    var dubbIndex = 0;//配音索引
    //vclick 点击事件
    //数据初始化
    subtitle(subtitleIndex);
    poster(posterIndex);
    dubbing(dubbIndex);
    //$.mobile.loading('show', {
    //    text: '加载中...', //加载器中显示的文字  
    //    textVisible: true, //是否显示文字  
    //    theme: 'e',        //加载器主题样式a-e  
    //    textonly: false,   //是否只显示文字  
    //    html: ""           //要显示的html内容，如图片等  
    //});
    //subtitle(subtitleIndex);
    var winH = $(window).height(); //页面可视区域高度 
    ScrollLoadData(subtitleIndex,posterIndex,dubbIndex, winH);
    infoByImg();
    
})
//字幕秀加载
function subtitle(index)
{ 
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/SubTitleShow/Index',
        data: { pageIndex: index, pageSize: 10 },
        type: 'get',
        dataType: 'json',
        success: function (data)
        {
            var html = data.data;
            if (data.state!=1)
            {
                alert(data.msg); return;
            }
            $("#subtitle").append(html);
        }, error: function (a, c, v)
        {
            alert("错误");
        }
    })
}

//海报秀加载
function poster(index)
{
    
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/PosterShow/Index',
        data: { pageIndex: index },
        type: 'get',
        dataType: 'json',
        success: function (data)
        {
            var html = data.data;
            if (data.state != 1)
            {
                alert(data.msg); return;
            }
            $("#poster").append(html);

        }, error: function (a, c, v)
        {
            alert("错误");
        }
    });
}

//配音秀加载
function dubbing(index)
{
    
    $.ajax({
        url: 'http://devftp.lansum.cn/fishapi/api/DubbingShow/Index',
        data: { pageIndex: index },
        type: 'get',
        dataType: 'json',
        success: function (data)
        {
            var html = data.data;
            if (data.state != 1)
            {
                alert(data.msg); return;
            }
            $("#dub").append(html);

        }, error: function (a, c, v)
        {
            alert("错误");
        }
    });
}


 

function ScrollLoadData(subtitleIndex,posterIndex,dubbIndex, winH)
{
    //$(document).on("scrollstop", function ()
    //{
    //    //alert("停止滚动!");
    //    var pageH = $(document.body).height();
    //    var scrollT = $(window).scrollTop(); //滚动条top 
    //    var aa = (pageH - winH - scrollT) / winH;
    //    if (aa < 0.02)
    //    {
    //        Change(++subtitleIndex, ++posterIndex, ++dubbIndex)
    //    }
    //});
}
function Change(i1,i2,i3)
{
    if ($("#subtitle").hasClass("active"))//字幕秀
    {
        subtitle(i1);
    }
    else if ($("#poster").hasClass("active"))//海报
    {
        poster(i2);
    }
    else //配音dub
    {
        dubbing(i3);
    }
}


