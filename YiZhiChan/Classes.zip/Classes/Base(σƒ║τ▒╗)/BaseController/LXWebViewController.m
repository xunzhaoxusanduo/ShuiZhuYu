//
//  LXWebViewController.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/29.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXWebViewController.h"
#import "UINavigationBar+Extend.h"
#import "LXMovieViewController.h"
#import "MJRefresh.h"
#import "MBProgressHUD+MJ.h"
#import "AFNetworking.h"
#import "Masonry.h"
#import "Macros.h"
#import "WebViewJavascriptBridge.h"

#ifdef Unity
#import "UnityAppController.h"
#endif

@interface LXWebViewController () <UIWebViewDelegate, UIScrollViewDelegate>

@property (nonatomic, strong)UIWebView *webView;
@property (nonatomic, strong)MBProgressHUD *hud;
@property (nonatomic, strong)NSTimer *timer;
@property (nonatomic, strong)UIView *reloadBgView;
@property (nonatomic, strong)WebViewJavascriptBridge* bridge;
@property (nonatomic, assign)CGFloat imageHeight;

@end

@implementation LXWebViewController

- (instancetype)initWithUrl:(NSURL *)url {
    if (self = [super init]) {
        self.url = url;
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setupWebView];
    [self setupNoNetwork];
    [self setupRefreshView];
    
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        if (status == AFNetworkReachabilityStatusNotReachable) {
            [MBProgressHUD showError:@"您的网络好像不太顺畅！"];
        }
    }];
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
}

- (void)setupWebView {
    UIWebView *webView = [[UIWebView alloc] init];
    webView.frame = self.view.frame;
    webView.delegate = self;
    webView.scrollView.delegate = self;
    [self.view addSubview:webView];
    self.webView = webView;
    
    self.bridge = [WebViewJavascriptBridge bridgeForWebView:self.webView];
    [self.bridge setWebViewDelegate:self];
    [self.bridge registerHandler:@"handleArPosterFromJS" handler:^(id data, WVJBResponseCallback responseCallback) {
        NSLog(@"handleArPosterFromJS called: %@", data);
        #ifdef Unity
        [self presentViewController:[GetAppController() rootViewController] animated:YES completion:nil];
        [GetAppController() restartUnity];
        #endif
    }];
    
    if (self.url) {
        NSURLRequest *request = [NSURLRequest requestWithURL:self.url];
        [self.webView loadRequest:request];
    }
}

/**
 *  添加网络不可用时的提示控件
 */
- (void)setupNoNetwork {
    WS(weakself);
    
    UIView *reloadBgView = [[UIView alloc] init];
    reloadBgView.backgroundColor = [UIColor whiteColor];
    reloadBgView.hidden = YES;
    [self.webView addSubview:reloadBgView];
    self.reloadBgView = reloadBgView;
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"global_no_network"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    [reloadBgView addSubview:imageView];
    
    UILabel *label = [[UILabel alloc] init];
    label.text = @"亲，您的手机网络不太顺畅喔~";
    [reloadBgView addSubview:label];
    
    UIButton *reloadBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [reloadBtn setTitle:@"重新加载" forState:UIControlStateNormal];
    [reloadBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [reloadBtn addTarget:self action:@selector(reloadWebView) forControlEvents:UIControlEventTouchUpInside];
    reloadBtn.layer.borderColor = [UIColor grayColor].CGColor;
    reloadBtn.layer.borderWidth = 1.0f;
    reloadBtn.layer.cornerRadius = 5.0f;
    [reloadBgView addSubview:reloadBtn];
    
    [reloadBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(weakself.webView);
    }];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakself.reloadBgView.mas_centerX);
        make.centerY.equalTo(weakself.reloadBgView.mas_centerY).offset(-20);
        make.size.mas_equalTo(CGSizeMake(100, 100));
    }];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakself.reloadBgView.mas_centerX);
        make.top.mas_equalTo(imageView.mas_bottom);
        make.height.mas_equalTo(20);
    }];
    
    [reloadBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakself.reloadBgView.mas_centerX);
        make.top.mas_equalTo(label.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(100, 30));
    }];
}

/**
 *  集成刷新控件
 */
- (void)setupRefreshView
{
    __unsafe_unretained UIWebView *webView = self.webView;
    __unsafe_unretained UIScrollView *scrollView = self.webView.scrollView;
    
    // 添加下拉刷新控件
    scrollView.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [webView reload];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"viewWillAppear");
    
    // 页面顶部是图片，navBar颜色需要渐变
    if ([self.url.absoluteString containsString:@"shuizhuyu.bundle"]) {
        self.automaticallyAdjustsScrollViewInsets = NO;
        [self.navigationController.navigationBar lt_setBackgroundColor:[UIColor clearColor]];
        // 保证每次进入的时候，navBar渐变的状态和上次一样
        [self scrollViewDidScroll:self.webView.scrollView];
    }else {//// 页面顶部不是图片，navBar颜色不需要渐变
        self.automaticallyAdjustsScrollViewInsets = YES;
        [self.navigationController.navigationBar lt_setBackgroundColor:NavBarBackgroundColour];
    }
    
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [self hideProgressHUD];
}

#pragma mark - UIWebViewDelegate代理方法
/**
 *  是否加载
 *
 */
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSLog(@"\r\n");
    NSLog(@"shouldStartLoadWithRequest");
    
//    NSLog(@"load   URL--------- %@", request.URL.absoluteString);
//    NSLog(@"currnt URL--------- %@", self.url.absoluteString);
    
    // 网络可用
    if ([[AFNetworkReachabilityManager sharedManager] isReachable]) {
        self.reloadBgView.hidden = YES;
        
        if (self.hud == nil) {
            self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            if (self.timer == nil) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:15.0 target:self selector:@selector(progressHUDTimer) userInfo:nil repeats:YES];
            }
        }
    }else {// 网络不可用
        self.reloadBgView.hidden = NO;
    }

    if (request.URL == nil) {
        return YES;
    }
    
    if ([request.URL.absoluteString isEqualToString:@"about:blank"]) {
        return YES;
    }
    
    if ([request.URL.absoluteString isEqualToString:self.url.absoluteString]) {
        return YES;
    }
    
    NSLog(@"navigationType = %ld", navigationType);
    
    switch (navigationType) {
        case UIWebViewNavigationTypeLinkClicked: {
            [self hideProgressHUD];
            LXWebViewController* webViewController = [[LXWebViewController alloc] initWithUrl:request.URL];
            [self.navigationController pushViewController:webViewController animated:YES];
            return NO;
            break;
        }
        case UIWebViewNavigationTypeFormSubmitted: {
            [self hideProgressHUD];
            LXWebViewController* webViewController = [[LXWebViewController alloc] initWithUrl:request.URL];
            [self.navigationController pushViewController:webViewController animated:YES];
            return NO;
            break;
        }
        case UIWebViewNavigationTypeBackForward: {
            break;
        }
        case UIWebViewNavigationTypeReload: {
            break;
        }
        case UIWebViewNavigationTypeFormResubmitted: {
            break;
        }
        case UIWebViewNavigationTypeOther: {
            break;
        }
        default: {
            break;
        }
    }

    return YES;
}

/**
 *  开始加载
 *
 */
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

/**
 *  加载完成
 *
 */
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    NSLog(@"webViewDidFinishLoad");
    [self hideProgressHUD];
    
    // 防止当前控制器为navigationController的根控制器，如果title从网页获取，造成tabBar的标题改变
    if ([self.navigationController.viewControllers count] > 1) {
        NSString *theTitle=[webView stringByEvaluatingJavaScriptFromString:@"document.title"];
        if (theTitle.length > 10) {
            theTitle = [[theTitle substringToIndex:9] stringByAppendingString:@"…"];
        }
        self.title = theTitle;
    }
    
    self.imageHeight = [[webView stringByEvaluatingJavaScriptFromString:@"getImageHeight()"] floatValue];
    NSLog(@"%f", self.imageHeight);
}

/**
 *  加载失败
 *
 */
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    [self hideProgressHUD];
}

#pragma mark - UIScrollViewDelegate代理方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (self.imageHeight > 0) {
        UIColor *color = NavBarBackgroundColour;
        CGFloat offsetY = scrollView.contentOffset.y;
        NSLog(@"%f", offsetY);
        if (offsetY > 0) {
            CGFloat alpha = MIN(MinNavBarAlpha, 1 - ((self.imageHeight - 64 - offsetY) / 64));
            [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:alpha]];
        } else {
            [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:0]];
        }
    }
}

#pragma mark - 私有方法
/**
 *  隐藏下拉刷新和加载提示
 */
- (void)hideProgressHUD {
    if (self.hud) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        self.hud = nil;
    }
    
    [self.webView.scrollView.mj_header endRefreshing];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

/**
 *  下拉刷新和加载提示超时处理
 */
- (void)progressHUDTimer {
    if (self.timer) {
        if ([self.timer isValid]) {
            [self.timer invalidate];
            self.timer = nil;
            [self hideProgressHUD];
        }
    }
}

/**
 *  重新加载网页
 */
- (void)reloadWebView {
    [self.webView reload];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

@end
