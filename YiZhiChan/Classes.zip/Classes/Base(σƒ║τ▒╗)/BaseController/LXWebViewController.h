//
//  LXWebViewController.h
//  YiZhiChan
//
//  Created by wuyaju on 16/4/29.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXBaseViewController.h"

@interface LXWebViewController : LXBaseViewController

@property (nonatomic, copy)NSURL *url;

- (instancetype)initWithUrl:(NSURL *)url;

@end
