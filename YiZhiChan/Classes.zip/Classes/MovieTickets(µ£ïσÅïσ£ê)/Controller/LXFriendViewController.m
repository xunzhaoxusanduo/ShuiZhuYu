//
//  LXFriendViewController.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/30.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXFriendViewController.h"
#import "UINavigationBar+Extend.h"

@interface LXFriendViewController ()

@end

@implementation LXFriendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"朋友圈";
}

@end
