//
//  LXMeViewController.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/30.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXMeViewController.h"
#import "UINavigationBar+Extend.h"

@interface LXMeViewController ()

@end

@implementation LXMeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"我的";
}

@end
