//
//  LXPlayViewController.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/30.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXPlayViewController.h"
#import "UINavigationBar+Extend.h"

@interface LXPlayViewController ()

@end

@implementation LXPlayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"玩吧";
}

@end
