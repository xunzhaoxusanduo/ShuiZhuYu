//
//  LXMovieViewController.m
//  YiZhiChan
//
//  Created by wuyaju on 16/4/30.
//  Copyright © 2016年 吴亚举. All rights reserved.
//

#import "LXMovieViewController.h"
#import "UINavigationBar+Extend.h"

@interface LXMovieViewController () <UIWebViewDelegate>

@end

@implementation LXMovieViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"电影票";
}

@end
